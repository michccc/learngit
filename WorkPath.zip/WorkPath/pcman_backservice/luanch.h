#ifndef LUANCH_H
#define LUANCH_H

#include <QObject>

class luanch : public QObject
{
    Q_OBJECT
public:
    explicit luanch(QObject *parent = nullptr);

signals:

public slots:
};

#endif // LUANCH_H