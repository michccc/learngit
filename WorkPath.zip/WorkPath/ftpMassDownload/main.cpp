#include "ftpmassdown.h"
#include <QApplication>
#include <QDBusConnection>
#include <QCoreApplication>
#include <QDBusConnection>
#include <QDebug>
#include <QDBusError>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //建立到session bus的连接
    QDBusConnection connection = QDBusConnection::sessionBus();
    FTPMassDown w;
    //在session bus上注册名为com.scorpio.test的服务
    if(!connection.registerService("com.scorpio.test"))
    {
        qDebug() << "error:" << connection.lastError().message();
        exit(-1);
    }
    //注册名this到路径/test/objects，把this导出为method
    connection.registerObject("/test/objects", &w, QDBusConnection::ExportAllContents);
    w.show();

    return a.exec();
}
