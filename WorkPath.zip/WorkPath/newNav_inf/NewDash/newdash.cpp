#include "newdash.h"
#include "ui_newdash.h"
#include <QtCharts>
#include <QPieSlice>
#include <QNetworkInterface>
#include <QProcess>
#include <QDebug>
#include <QPoint>
#include <QtGlobal>

NewDash::NewDash(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NewDash)
{
    ui->setupUi(this);


    slCPUcmd<<"-c"<<"top -b -n 1 | grep ' id'";
    slMEMcmd<<"-c"<<"free | grep Mem";
    slNETcmd<<"-c"<<"cat /sys";

    for (const QNetworkInterface &net: QNetworkInterface::allInterfaces()) {

        if ((net.flags()  & QNetworkInterface::IsUp) &&
            (net.flags()  & QNetworkInterface::IsRunning) &&
            !(net.flags() & QNetworkInterface::IsLoopBack))
        {
            defaultNetworkInterface = net.name();
            break;
        }
    }

    rxPath = QString("cat /sys/class/net/%1/statistics/rx_bytes").arg(defaultNetworkInterface);
    txPath = QString("cat /sys/class/net/%1/statistics/tx_bytes").arg(defaultNetworkInterface);

    rxMax= 1L << 10;//1占四个字节,将1二进制左移动10位,1024
    ui->labelDownSpeed->setText("      1KB/s");

    ui->labelDownSpeed->hide();
    ui->labelUpSpeed->hide();
    s = new speedyball(parent);
    s->move(1700,100);
    s->show();
    startTimer(1000);
    init();
}
void NewDash::timerEvent(QTimerEvent *event)
{
    Q_UNUSED(event);
    QProcess pInf;
    static int second = 0;
    for (int i = 0; i < (second < 61 ? second : 61); i++)
    {
       lineNetdown->replace(i, (i+1), lineNetdown->at(i).y());
       lineNetup->replace(i, (i+1), lineNetup->at(i).y());
    }

    if(second > 61)
    {
        lineNetdown->removePoints(61, 1);
        lineNetup->removePoints(61, 1);
    }
    qreal rdownR = -1;
    qreal rupT = -1;
    pInf.start(rxPath);
    pInf.waitForFinished();
    QString st = QString(pInf.readAllStandardOutput());
    if(second!=0)
    {
        rxSec=QString::number(st.toDouble()-rxTotal.toDouble());
        rdownR = rxSec.toDouble();
//        qDebug()<<rxSec;
    }
    rxTotal = st;
    QString sTDown;
    QString sUnitDown;
    qreal qr = -1;
    if(rxTotal.toDouble()<1L << 30)
        ui->labelTotal->setText("总量  "+QString::number(rxTotal.toDouble()/1024/1024,'f',1)+" MB");
    if(rxTotal.toDouble()<1L << 40&&rxTotal.toDouble()>1L << 30)
        ui->labelTotal->setText("总量  "+QString::number(rxTotal.toDouble()/1024/1024/1024,'f',1)+" GB");
    if(rdownR<(1L << 10))
    {
        sTDown = QString::number(rdownR,'f',1);
        sUnitDown = "B/s";
        qr = 1;
    }
    if(rdownR>=(1L << 10)&&rdownR<(1L << 20))
    {
        sTDown = QString::number(rdownR/1024,'f',1);
        sUnitDown = "KB/s";
        qr = 1024;
    }
    if(rdownR>=(1L << 20)&&rdownR<(1L << 30))
    {
        sTDown = QString::number(rdownR/1024/1024,'f',1);
        sUnitDown = "MB/s";
        qr = 1024/1024;
    }
    if(rdownR>=(1L << 30))
    {
        sTDown = QString::number(rdownR/1024/1024/1024,'f',1);
        sUnitDown = "GB/s";
        qr = 1024/1024/1024;
    }
    ui->labelSpeed->setText(sTDown);
    ui->labelunit->setText(sUnitDown);
    qreal qrq = rxMax;
    rxMax = qMax(rxMax,rdownR);//rxmax 1024
    if(qrq < rxMax)//qrq 1024
        ui->labelDownSpeed->setText("      "+QString::number(rxMax/qr,'f',1)+sUnitDown);
    s->SYBfloatdown(sTDown);//第二个参数可以不要
    s->SYBfloatdownunit(sUnitDown);

    chartNetdown->axisY()->setRange(0, rxMax);
    chartNetdown->axisY()->setLabelsVisible(false);
    chartNetdown->axisY()->setLineVisible(false);
//    chartNetdown->axisY()->labe
    lineNetdown->insert(0,QPointF(0,rdownR));
    ui->widgetDown->repaint();
    s->SYBfloatlinedown(rxMax,rdownR);



    pInf.start(txPath);
    pInf.waitForFinished();
    st.clear();
    st = QString(pInf.readAllStandardOutput());
    if(second!=0)
    {
        txSec=QString::number(st.toDouble()-txTotal.toDouble());
        rdownR = txSec.toDouble();
//        qDebug()<<txSec<<st;
    }
    txTotal = st;
    sTDown.clear();
    sUnitDown.clear();
    qr = -1;
    if(txTotal.toDouble()<1L << 30)
        ui->labelTotal_2->setText("总量  "+QString::number(txTotal.toDouble()/1024/1024,'f',1)+" MB");
    if(txTotal.toDouble()<1L << 40&&txTotal.toDouble()>1L << 30)
        ui->labelTotal_2->setText("总量  "+QString::number(txTotal.toDouble()/1024/1024/1024,'f',1)+" GB");
    if(rdownR<(1L << 10))
    {
        sTDown = QString::number(rdownR,'f',1);
        sUnitDown = "B/s";
        qr = 1;
    }
    if(rdownR>=(1L << 10)&&rdownR<(1L << 20))
    {
        sTDown = QString::number(rdownR/1024,'f',1);
        sUnitDown = "KB/s";
        qr = 1024;
    }
    if(rdownR>=(1L << 20)&&rdownR<(1L << 30))
    {
        sTDown = QString::number(rdownR/1024/1024,'f',1);
        sUnitDown = "MB/s";
        qr = 1024/1024;
    }
    if(rdownR>=(1L << 30))
    {
        sTDown = QString::number(rdownR/1024/1024/1024,'f',1);
        sUnitDown = "GB/s";
        qr = 1024/1024/1024;
    }
    ui->labelSpeed_2->setText(sTDown);
    ui->labelunit_2->setText(sUnitDown);
    s->SYBfloatup(sTDown);
    s->SYBfloatupunit(sUnitDown);
    qreal qrqu = txMax;
    txMax = qMax(txMax,rdownR);
    if(qrqu < txMax)
        ui->labelUpSpeed->setText("      "+QString::number(txMax/qr,'f',1)+sUnitDown);
    chartNetup->axisY()->setRange(0, txMax);
    chartNetup->axisY()->setLabelsVisible(false);
    chartNetup->axisY()->setLineVisible(false);
//    chartNetdown->axisY()->labe
    lineNetup->insert(0,QPointF(0,rdownR));
    ui->widgetDown_2->repaint();
    s->SYBfloatlineup(txMax,rdownR);

    second++;



    pInf.start("/bin/bash",slMEMcmd);
    pInf.waitForFinished();
    QString sMem = QString(pInf.readAllStandardOutput()).trimmed();
    sMem = sMem.right(sMem.length()-4).trimmed();
    QStringList slMem = sMem.split(' ');
    qreal imem0 = -1;
    qreal imem1 = -1;
    qreal iparmem = -1;
    if(slMem.count()>5)
    {
        imem0 = slMem.first().toInt();
        imem1 = slMem.last().toInt();
        iparmem = imem1/imem0;
        ui->labelmemuse->setText(QString::number((imem0-imem1)/1024/1024,'f',1)+"GB");
        ui->labelmemtotal->setText("总量 "+QString::number((imem0)/1024/1024,'f',1)+"GB");
    }


    pInf.start("/bin/bash",slCPUcmd);
    pInf.waitForFinished();
    QStringList slCPU = QString(pInf.readAllStandardOutput()).split('\n');
    qreal icpu = -1;

    if(slCPU.count()>1)
    {
        QStringList slCPUi = slCPU.first().split(',');

        for(int i = 0 ; i < slCPUi.count();i++)
        {
            if(slCPUi[i].contains(" id",Qt::CaseInsensitive))
            {
//                qDebug()<<slCPUi[i];
                icpu = slCPUi[i].left(slCPUi[i].length()-3).toDouble();
                ui->labelLOAD->setText(QString::number(100-icpu,'f',1)+"%");
//                f->fslCPU(icpu);
            }
        }
    }

    s->SYBtime(icpu,imem0,imem1);
//    f->fslCPU(icpu);
    updateData(100-iparmem*100,iparmem*100,100-icpu,icpu,0,0);
//    qDebug()<<sMem;//QString(pInf.readAllStandardOutput()).trimmed().right(QString(pInf.readAllStandardOutput()).trimmed().count()-4);
    s->SYBloadpic(icpu);
}
void NewDash::updateData(qreal iMEM0,qreal iMEM1,qreal iCPU0,qreal iCPU1,int idown,int iup)
{
    sliceMEM0->setValue(iMEM0);
    sliceMEM1->setValue(iMEM1);

    slice0->setValue(iCPU0);
    slice1->setValue(iCPU1);
}
void NewDash::init()
{
//    axisDown = new QCategoryAxis;
//    axisUp = new QCategoryAxis;
//    axisDown->setLabelsPosition(QCategoryAxis::AxisLabelsPositionOnValue);

    serise->setHoleSize(0.75);
    serise->setPieSize(0.95);
//    serise->
//    serise->
    serise->setPieStartAngle(-120);
    serise->setPieEndAngle(120);
    slice0->setValue(40);
    slice1->setValue(60);
    slice1->setColor(QColor(241, 242, 245));
    slice0->setColor(QColor(61, 204, 123));
    serise->append(slice0);
    serise->append(slice1);
    chart->legend()->hide();
    chart->addSeries(serise);
    chart->createDefaultAxes();
    chart->createDefaultAxes();
//    chart->setAnimationOptions(QChart::AllAnimations);
    chart->setAnimationOptions(QChart::AnimationOption::GridAxisAnimations);
    ui->widget->setChart(chart);

    seriseMEM->setHoleSize(0.75);
    seriseMEM->setPieSize(0.95);
    seriseMEM->setPieStartAngle(-120);
    seriseMEM->setPieEndAngle(120);
    sliceMEM0->setValue(40);
    sliceMEM1->setValue(60);
    sliceMEM1->setColor(QColor(241, 242, 245));
    sliceMEM0->setColor(QColor(31, 201, 204));
    seriseMEM->append(sliceMEM0);
    seriseMEM->append(sliceMEM1);
    chartMEM->legend()->hide();
    chartMEM->addSeries(seriseMEM);
    chartMEM->createDefaultAxes();
    chartMEM->createDefaultAxes();
//    chartMEM->setAnimationOptions(QChart::AllAnimations);
    ui->widgetMem->setChart(chartMEM);


    qreal rDiskT = -1;
    qreal rDiskPar = -1;
    QString sHDD;
    QFile file("/home/diskinf.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            QByteArray line = file.readAll();
            QString str(line);
            sHDD = str;
        }
        file.close();
    }
    QStringList slHDD = sHDD.split("<==>");
    if (slHDD.count()>1)
    {
        QStringList sl0 = slHDD[0].split("\n");
        if(sl0.count()>1)
        {
            rDiskPar = sl0[1].toDouble();
            rDiskT=sl0[2].toDouble();
        }
    }
    seriseDISK->setHoleSize(0.75);
    seriseDISK->setPieSize(0.95);
    seriseDISK->setPieStartAngle(-120);
    seriseDISK->setPieEndAngle(120);
    ui->labelHDDtotal->setText("总量 "+QString::number(rDiskT/1024/1024/1024,'f',1)+"GB");
    ui->labelHDDuse->setText(QString::number(rDiskT*(rDiskPar/100)/1024/1024/1024,'f',1)+"GB");
    sliceDISK0->setValue(rDiskPar);
    sliceDISK1->setValue(100-rDiskPar);
    sliceDISK1->setColor(QColor(241, 242, 245));
    sliceDISK0->setColor(QColor(115, 132, 230));
    seriseDISK->append(sliceDISK0);
    seriseDISK->append(sliceDISK1);
    chartDISK->legend()->hide();
    chartDISK->addSeries(seriseDISK);
    chartDISK->createDefaultAxes();
    chartDISK->createDefaultAxes();
//    chartDISK->setAnimationOptions(QChart::AllAnimations);
    ui->widgetDisk->setChart(chartDISK);

    lineNetdown->setColor(QColor(31, 201, 204));
    lineNetdown->setPen(QPen(QBrush(QColor(31, 201, 204)),3,Qt::SolidLine));
    chartNetdown->addSeries(lineNetdown);
    chartNetdown->createDefaultAxes();
    chartNetdown->legend()->hide();
    chartNetdown->axisX()->hide();
    chartNetdown->axisX()->setRange(0, 60);
    chartNetdown->axisX()->setReverse(true);
    chartNetdown->axisY()->setLabelsVisible(false);
    chartNetdown->axisY()->setLineVisible(false);
    chartNetdown->setMargins(QMargins(0, 72, 24, 12));
//    chartNetdown->setAnimationOptions(QChart::AllAnimations);
    ui->widgetDown->setChart(chartNetdown);

    lineNetup->setColor(QColor(61, 204, 123));
    lineNetup->setPen(QPen(QBrush(QColor(61, 204, 123)),3,Qt::SolidLine));
    chartNetup->addSeries(lineNetup);
    chartNetup->createDefaultAxes();
    chartNetup->legend()->hide();
    chartNetup->axisX()->hide();
    chartNetup->axisX()->setRange(0, 60);
    chartNetup->axisX()->setReverse(true);
    chartNetup->axisY()->setLabelsVisible(false);
    chartNetup->axisY()->setLineVisible(false);

    chartNetup->setMargins(QMargins(0, 72, 24, 12));
    ui->widgetDown_2->setChart(chartNetup);
}
NewDash::~NewDash()
{
    delete ui;
}
