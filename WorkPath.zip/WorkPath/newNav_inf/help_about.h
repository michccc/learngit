#ifndef HELP_ABOUT_H
#define HELP_ABOUT_H

#include <QDialog>

namespace Ui {
class help_about;
}

class help_about : public QDialog
{
    Q_OBJECT

public:
    explicit help_about(QWidget *parent = nullptr);
    ~help_about();

    QString strVer;

private slots:
    void on_pushButton_clicked();

private:
    Ui::help_about *ui;
};

#endif // HELP_ABOUT_H
