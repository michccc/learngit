#include "luanch.h"
#include "backdbus_adaptor.h"
luanch::luanch(QObject *parent) : QObject(parent)
{

}
