#ifndef DIALOG_STARTUP_H
#define DIALOG_STARTUP_H

#include <QDialog>


namespace Ui {
class Dialog_startup;
}

class Dialog_startup : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_startup(QString sFile, QWidget *parent = nullptr);
    ~Dialog_startup();
    QString sCon;
    QString sCAN0;
    QString sCAN1;
    QWidget *w;
    bool bE;
    QString sfileP;
    QString savePath;

private slots:
    void on_pushButton_can_clicked();

    void on_pushButton_ok_clicked();

private:
    Ui::Dialog_startup *ui;
};

#endif // DIALOG_STARTUP_H
