#ifndef DBUSPAR_H
#define DBUSPAR_H

#include <QObject>

class dbusPar : public QObject
{
    Q_OBJECT
public:
    explicit dbusPar(QObject *parent = nullptr);
public Q_SLOTS:
    void clean();
    void boot();
    void uninstall();
    void closewindow();

Q_SIGNALS:
    void crashed();
signals:

};

#endif // DBUSPAR_H
