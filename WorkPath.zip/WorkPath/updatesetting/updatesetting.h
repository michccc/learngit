#ifndef UPDATESETTING_H
#define UPDATESETTING_H

#include <QWidget>
#include <QSettings>

namespace Ui {
class UpdateSetting;
}

class UpdateSetting : public QWidget
{
    Q_OBJECT

public:
    explicit UpdateSetting(QWidget *parent = nullptr);
    ~UpdateSetting();
    QSettings settings;

private slots:
    void on_radioButton_clicked();

    void on_radioButton_2_clicked();

private:
    Ui::UpdateSetting *ui;
};

#endif // UPDATESETTING_H
