#include "updatesetting.h"
#include "ui_updatesetting.h"

UpdateSetting::UpdateSetting(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UpdateSetting)
{
    ui->setupUi(this);
}

UpdateSetting::~UpdateSetting()
{
    delete ui;
}

void UpdateSetting::on_radioButton_clicked()
{
    QSettings settings("/home/Update.ini",QSettings::IniFormat);
    settings.beginGroup("UPDATE");
    settings.setValue("address","1.1.1.1");
    settings.setValue("port",21);
    settings.setValue("method","internet");
    settings.endGroup();
}

void UpdateSetting::on_radioButton_2_clicked()
{
    QSettings settings("/home/Update.ini",QSettings::IniFormat);
    settings.beginGroup("UPDATE");
    settings.setValue("address","1.1.1.1");
    settings.setValue("port",21);
    settings.setValue("method","LAN");
    settings.endGroup();
}
