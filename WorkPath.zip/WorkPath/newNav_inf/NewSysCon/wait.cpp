#include "wait.h"

wait::wait(QObject *parent) : QObject(parent)
{

}
