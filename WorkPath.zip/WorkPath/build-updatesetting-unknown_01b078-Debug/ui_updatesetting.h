/********************************************************************************
** Form generated from reading UI file 'updatesetting.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATESETTING_H
#define UI_UPDATESETTING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UpdateSetting
{
public:
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;

    void setupUi(QWidget *UpdateSetting)
    {
        if (UpdateSetting->objectName().isEmpty())
            UpdateSetting->setObjectName(QStringLiteral("UpdateSetting"));
        UpdateSetting->resize(452, 372);
        horizontalLayout = new QHBoxLayout(UpdateSetting);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        groupBox = new QGroupBox(UpdateSetting);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setFocusPolicy(Qt::NoFocus);

        verticalLayout->addWidget(radioButton);

        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setFocusPolicy(Qt::NoFocus);

        verticalLayout->addWidget(radioButton_2);


        horizontalLayout->addWidget(groupBox);


        retranslateUi(UpdateSetting);

        QMetaObject::connectSlotsByName(UpdateSetting);
    } // setupUi

    void retranslateUi(QWidget *UpdateSetting)
    {
        UpdateSetting->setWindowTitle(QApplication::translate("UpdateSetting", "UpdateSetting", nullptr));
        groupBox->setTitle(QApplication::translate("UpdateSetting", "\350\256\276\347\275\256\346\216\245\346\224\266\346\216\250\351\200\201\347\232\204\346\226\271\345\274\217", nullptr));
#ifndef QT_NO_TOOLTIP
        radioButton->setToolTip(QApplication::translate("UpdateSetting", "<html><head/><body><p>\344\273\216\350\277\234\347\250\213\346\234\215\345\212\241\345\231\250\344\270\212\346\216\245\345\217\227\350\275\257\344\273\266\345\215\207\347\272\247\347\232\204\346\217\220\351\200\201\357\274\214\345\275\223\346\202\250\345\217\257\344\273\245\350\277\236\346\216\245\345\210\260Internet\346\227\266\357\274\214\345\273\272\350\256\256\346\202\250\345\272\224\350\257\245\351\200\211\346\213\251\350\277\231\347\247\215\346\226\271\345\274\217</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        radioButton->setText(QApplication::translate("UpdateSetting", "\344\273\216Internet\346\216\245\346\224\266\345\215\207\347\272\247\346\216\250\351\200\201", nullptr));
#ifndef QT_NO_TOOLTIP
        radioButton_2->setToolTip(QApplication::translate("UpdateSetting", "<html><head/><body><p>\344\273\216\346\202\250\347\232\204\350\256\241\347\256\227\346\234\272\346\211\200\345\244\204\347\232\204\345\261\200\345\237\237\347\275\221\344\270\255\347\232\204\346\234\215\345\212\241\345\231\250\346\216\245\346\224\266\345\215\207\347\272\247\346\216\250\351\200\201\357\274\214\345\275\223\346\202\250\346\211\200\345\234\250\347\232\204\345\205\254\345\217\270\346\210\226\347\273\204\347\273\207\347\232\204\345\261\200\345\237\237\347\275\221\344\270\255\346\220\255\345\273\272\344\272\206\345\215\207\347\272\247\346\234\215\345\212\241\345\231\250\346\230\257\357\274\214\346\202\250\345\272\224\345\275\223\351\200\211\346\213\251\350\277\231\347\247\215\346\226\271\345\274\217</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        radioButton_2->setText(QApplication::translate("UpdateSetting", "\344\273\216\345\261\200\345\237\237\347\275\221\346\234\215\345\212\241\345\231\250\346\216\245\346\224\266\345\215\207\347\272\247\346\216\250\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UpdateSetting: public Ui_UpdateSetting {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATESETTING_H
