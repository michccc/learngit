#ifndef FTPMASSDOWN_H
#define FTPMASSDOWN_H

#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QFile>
#include <QDebug>
#include <QMessageBox>
#include <QStringList>
#include <QUdpSocket>

namespace Ui {
class FTPMassDown;
}

class FTPMassDown : public QWidget
{
    Q_OBJECT
    //定义Interface名称为com.scorpio.test.value
    Q_CLASSINFO("D-Bus Interface", "com.scorpio.test.value")
public:
    explicit FTPMassDown(QWidget *parent = nullptr);
    ~FTPMassDown();
    QUdpSocket *pUDPc;
    struct strUdpc
    {
        unsigned char ip0;
        unsigned char ip1;
        unsigned char ip2;
        unsigned char ip3;
        unsigned char prot0;
        unsigned char prot1;
        union uprot
        {
            unsigned char cprot[2];
            unsigned short int iprot;
        }uninport;
    };
    struct waniport
    {
       int port;
       QString ip;
    };
    waniport strwan;
    strUdpc strUDP;
    void ftpDown(QString sADDR, int iPORT, QString sLFname, QString sRFname);
    void getudpiport();
    bool islanwan();
    QString lscpu();
    QString cpubuild();
    bool aptlist(QString filename,QString filever);
    void aptget(QString filename);
    bool ishave();
    void getwaniport();
public slots:  
    QString getlocalip();
private slots:
    void on_pushButton_clicked();
    void on_butGetPack_clicked();

private:
    Ui::FTPMassDown *ui;
};

#endif // FTPMASSDOWN_H
