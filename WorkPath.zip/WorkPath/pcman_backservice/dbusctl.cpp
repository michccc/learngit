#include "dbusctl.h"


Dbusctl::Dbusctl(QObject *parent) : QObject(parent)
{

}
