#include "new_navinf.h"
#include "ui_new_navinf.h"
#include <QScreen>
#include "SystemInf/systeminf.h"
#include <QProcess>
#include <QMessageBox>
#include "signal_adaptor.h"
//#include "changewall.h"
//#include "help_about.h"
//static changeWall  *cw;//  = new changeWall();

New_NavInf::New_NavInf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::New_NavInf)
{
    ui->setupUi(this);
    // 创建QDBusInterface接口
    QDBusInterface interface("com.scorpio.test", "/test/objects",
                             "com.scorpio.test.value",
                             QDBusConnection::sessionBus());
    if(!interface.isValid())
    {
        qDebug() << qPrintable(QDBusConnection::sessionBus().lastError().message());
                exit(1);
    }
//    this->setWindowFlags(Qt::Window | Qt::CustomizeWindowHint);
      this->setWindowFlags(Qt::FramelessWindowHint | Qt::Tool | Qt::WindowStaysOnTopHint);
//    this->setWindowFlags(Qt::Tool | Qt::WindowStaysOnTopHint | Qt::X11BypassWindowManagerHint);
//    this->setAttribute(Qt::WA_TranslucentBackground);
//    this->setStyleSheet("bckground-image: url(:/PCman_RES/background.png);");
//    f = new floatpan(this);
    ui->butres->hide();
    ui->buthelp->hide();
    cw = nullptr;
    ha = nullptr;
    mMenu = new QMenu(this);
    mStartUp = new QAction("开机启动",this);
    mExit = new QAction("退出",this);
    mChangeWall = new QAction("更换壁纸",this);
    syncStartUp();


    QFont font ( "Noto Sans CJK SC", 24, 63);
    ui->label->setFont(font);

//    ui->toolhelp->hide();


    QScreen *screen=QGuiApplication::primaryScreen ();
    QRect mm=screen->availableGeometry() ;
    int screen_width = mm.width();
    int screen_height = mm.height();

//    this->setWindowFlag(Qt::FramelessWindowHint);
//    this->setAttribute(Qt::WA_TranslucentBackground);
    this->move(360,165);

    this->setFixedHeight(750);
    this->setFixedWidth(1200);
    ui->sidebar->setFixedWidth(160);
    //服务端，不知道干啥的
    new StartupAdaptor(this);
    QDBusConnection connection = QDBusConnection::sessionBus();//建立到session bus的连接
    connection.registerObject("/stup",this);//注册对象名，第二个参数不懂
    connection.registerService("org.stup.Stup");//注册服务名称

    ui->horizontalLayout_Widget->setMargin(0);
    ui->labTitle->setMaximumHeight(screen_height*0.03);
    ui->labTitle->setMaximumWidth(screen_width/12);
    QImage im;
    im.load(":/PCman_RES/logo.png");
    im.scaled(ui->labTitle->size(), Qt::KeepAspectRatio);
    ui->labTitle->setScaledContents(true);
    QPixmap pix = QPixmap::fromImage(im);
    ui->labTitle->setPixmap(pix);

    ui->butinf->installEventFilter(this);
    ui->butdash->installEventFilter(this);
    ui->butsoft->installEventFilter(this);
    ui->butsys->installEventFilter(this);
    ui->butres->installEventFilter(this);
//    ui->but360->installEventFilter(this);

    lWpage.clear();
    sysinf = new systeminf(this);
    ui->verticalLayout_2->addWidget(sysinf);
    lWpage.append(sysinf);

    dashboard= new NewDash(this);
    ui->verticalLayout_2->addWidget(dashboard);
    dashboard->hide();
    lWpage.append(dashboard);

    syscon= new Widget(this);
    ui->verticalLayout_2->addWidget(syscon);

    syscon->hide();
    lWpage.append(syscon);

    soft= new softMan(this);
    ui->verticalLayout_2->addWidget(soft);
    soft->hide();
    lWpage.append(soft);

    mSysTrayIcon = new QSystemTrayIcon(this);
    QIcon icon = QIcon(":/PCman_RES/BigLogo.png");
    mSysTrayIcon->setIcon(icon);
    mSysTrayIcon->setToolTip(QObject::trUtf8("同方电脑管家"));
    mSysTrayIcon->show();





    mMenu->setStyleSheet("QMenu::indicator:exclusive:checked{image:url(:/PCman_RES/checek.png)}");


    QString sPATH;
    sPATH = QDir::homePath()+"/.config/autostart/";
    QDir dir(sPATH);
    QStringList nameFilters;
    nameFilters<<"*.desktop";
    QStringList slfiles = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
//    qDebug()<<slfiles;
    QString sfCon;

    connect(mStartUp,SIGNAL(triggered()),this,SLOT(on_setStartUp()));
    connect(mChangeWall,SIGNAL(triggered()),this,SLOT(on_changeWall()));
    connect(mExit,SIGNAL(triggered()),this,SLOT(on_exitApp()));
    mMenu->addAction(mStartUp);
    mMenu->addAction(mChangeWall);
    mMenu->addAction(mExit);
    mSysTrayIcon->setContextMenu(mMenu);
    connect(mSysTrayIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason)));

    mStartUp->setCheckable(true);
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_select.png"));
    binfHover = false;

//    QDBusInterface interface("com.scorpio.test", "/test/objects",
//                                 "com.scorpio.test.value",
//                                 QDBusConnection::sessionBus());
}
void New_NavInf::on_exitApp()
{
 confirmQuit();
}

void New_NavInf::on_changeWall()
{
    if(cw==nullptr)
    {
        cw = new changeWall();
        cw->move(1920/2-500,1080/2-300);
        cw->show();
    }
    else
    {
        if(cw!=nullptr)
        {
            cw->move(1920/2-500,1080/2-300);
            cw->show();
        }
    }

    QObjectList obl = this->children();

}

void New_NavInf::on_setStartUp()
{
    QString sPATH;
    sPATH = QDir::homePath()+"/.config/autostart/";
    qDebug()<<sPATH;
    QDir dir(sPATH);
    QStringList nameFilters;
    nameFilters<<"*.desktop";
    QStringList slfiles = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
//    qDebug()<<slfiles;
    QString sfCon;
    bool bSup = false;
    for(int i = 0 ; i < slfiles.count();i++)
    {
        sfCon.clear();
        QFile fDesk(sPATH+slfiles[i]);
        if (fDesk.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            while (!fDesk.atEnd())
            {
                QByteArray line = fDesk.readAll();
                QString str(line);
                sfCon = str;
            }
            fDesk.close();
        }

        if(sfCon.contains("newNav_inf /hide",Qt::CaseInsensitive)&&sfCon.contains("Hidden=true",Qt::CaseInsensitive))
        {
            fDesk.open(QIODevice::WriteOnly);
            fDesk.close();
            if (fDesk.open(QIODevice::ReadWrite | QIODevice::Text))
            {
                QStringList slSave;
                slSave<<"[Desktop Entry]"<<"Comment=Comment"<<"Type=Application"<<"Terminal=false"<<"Name=pcman"
                     <<"Exec=/usr/bin/newNav_inf /hide"<<"Hidden=false"<<"Icon=/usr/share/logo.png";

                QTextStream ts(&fDesk);
                ts.seek(fDesk.size());
                for(int f = 0 ; f < slSave.count() ; f++)
                {
                    ts<<slSave[f]<<"\n";
                }
                fDesk.close();
            }
            bSup=true;
        }

        if(sfCon.contains("newNav_inf /hide",Qt::CaseInsensitive)&&sfCon.contains("Hidden=false",Qt::CaseInsensitive))
        {
            fDesk.open(QIODevice::WriteOnly);
            fDesk.close();
            if (fDesk.open(QIODevice::ReadWrite | QIODevice::Text))
            {
                QStringList slSave;
                slSave<<"[Desktop Entry]"<<"Comment=Comment"<<"Type=Application"<<"Terminal=false"<<"Name=pcman"
                     <<"Exec=/usr/bin/newNav_inf /hide"<<"Hidden=true"<<"Icon=/usr/share/logo.png";

                QTextStream ts(&fDesk);
                ts.seek(fDesk.size());
                for(int f = 0 ; f < slSave.count() ; f++)
                {
                    ts<<slSave[f]<<"\n";
                }
                fDesk.close();
            }
            bSup=true;
        }


    }
    if(!bSup)
    {
        QFile fNewstart(QDir::homePath()+"/.config/autostart/tfpcmanstartup.desktop");
        fNewstart.open(QIODevice::WriteOnly);
        fNewstart.close();
        if (fNewstart.open(QIODevice::ReadWrite | QIODevice::Text))
        {
            QStringList slSave;
            slSave<<"[Desktop Entry]"<<"Comment=Comment"<<"Type=Application"<<"Terminal=false"<<"Name=pcman"
                 <<"Exec=/usr/bin/newNav_inf /hide"<<"Hidden=false"<<"Icon=/usr/share/logo.png";
            QTextStream ts(&fNewstart);
            ts.seek(fNewstart.size());
            for(int f = 0 ; f < slSave.count() ; f++)
            {
                ts<<slSave[f]<<"\n";
            }

            fNewstart.close();
        }
    }
    syscon->getStartup();
}
void New_NavInf::on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason)
{
    QString sPATH;
    sPATH = QDir::homePath()+"/.config/autostart/";
    QDir dir(sPATH);
    QStringList nameFilters;
    nameFilters<<"*.desktop";
    QStringList slfiles = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
//    qDebug()<<slfiles;
    QString sfCon;
//    bool bSup = false;
//    for(int i = 0 ; i < slfiles.count();i++)
//    {
//        sfCon.clear();
//        QFile fDesk(sPATH+slfiles[i]);
//        if (fDesk.open(QIODevice::ReadOnly | QIODevice::Text))
//        {
//            while (!fDesk.atEnd())
//            {
//                QByteArray line = fDesk.readAll();
//                QString str(line);
//                sfCon = str;
//            }
//            fDesk.close();
//        }

//        if(sfCon.contains("newNav_inf /hide",Qt::CaseInsensitive)&&sfCon.contains("Hidden=false",Qt::CaseInsensitive))
//        {
//            bSup=true;
//        }

//    }
//    mStartUp->setChecked(bSup);
    switch(reason)
    {
    case QSystemTrayIcon::Trigger:
        //单击托盘图标
        this->show();
        //        qDebug()<<"click";
        break;

    case QSystemTrayIcon::DoubleClick:
        //双击托盘图标

        break;
//    case QSystemTrayIcon::
        //双击托盘图标

//        break;
    default:
        break;
    }
}

void New_NavInf::selectPage(int index)
{
    for(int w = 0 ;w < lWpage.count() ; w++)
    {
        if(index == w)
        {
            lWpage[w]->show();
            ui->label->setText(lWpage[w]->windowTitle());
        }
        else
        {
            lWpage[w]->hide();
        }
    }
}

bool New_NavInf::eventFilter(QObject *obj, QEvent *event)
{
    switch (event->type()) {
    case QEvent::HoverEnter:
        if(obj == ui->butinf&&binfHover)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_hover.png"));
        if(obj == ui->butinf&&!binfHover)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_select.png"));

        if(obj == ui->butdash&&bdashHover)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_hover.png"));
        if(obj == ui->butdash&&!bdashHover)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_select.png"));

        if(obj == ui->butsys&&bsysConHover)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_hover.png"));
        if(obj == ui->butsys&&!bsysConHover)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));

        if(obj == ui->butsoft&&bsoftHover)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_hover.png"));
        if(obj == ui->butsoft&&!bsoftHover)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_select.png"));

        if(obj == ui->butres&&bResHover)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_hover.png"));
        if(obj == ui->butres&&!bResHover)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_select.png"));

//        if(obj == ui->but360&&b360Hover)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_hover.png"));
//        if(obj == ui->but360&&!b360Hover)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_hover.png"));
        break;

    case QEvent::HoverLeave:
        if(obj == ui->butinf&&binfHover)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));
        if(obj == ui->butinf&&!binfHover)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_select.png"));

        if(obj == ui->butdash&&bdashHover)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));
        if(obj == ui->butdash&&!bdashHover)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_select.png"));

        if(obj == ui->butsys&&bsysConHover)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));
        if(obj == ui->butsys&&!bsysConHover)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));

        if(obj == ui->butsoft&&bsoftHover)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));
        if(obj == ui->butsoft&&!bsoftHover)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_select.png"));

        if(obj == ui->butres&&bResHover)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));
        if(obj == ui->butres&&!bResHover)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_select.png"));

//        if(obj == ui->but360&&b360Hover)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_hover.png"));
//        if(obj == ui->but360&&!b360Hover)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
        break;

    case QEvent::MouseButtonPress:
        if(obj == ui->butinf)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_select.png"));
        if(obj == ui->butdash)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_select.png"));
        if(obj == ui->butsys)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));
        if(obj == ui->butsoft)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_select.png"));
        if(obj == ui->butres)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_select.png"));
//        if(obj == ui->but360)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_pressed.png"));
        break;
    case QEvent::MouseButtonRelease:
        if(obj == ui->butinf)
            ui->butinf->setIcon(QIcon(":/PCman_RES/information_select.png"));
        if(obj == ui->butdash)
            ui->butdash->setIcon(QIcon(":/PCman_RES/dash_select.png"));
        if(obj == ui->butsys)
            ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));
        if(obj == ui->butsoft)
            ui->butsoft->setIcon(QIcon(":/PCman_RES/process_select.png"));
        if(obj == ui->butres)
            ui->butres->setIcon(QIcon(":/PCman_RES/resources_select.png"));
//        if(obj == ui->but360)
//            ui->but360->setIcon(QIcon(":/PCman_RES/safe_pressed.png"));
        break;

    default:
        break;
    }
    return QWidget::eventFilter(obj, event);
}

New_NavInf::~New_NavInf()
{
    delete ui;
}

void New_NavInf::on_butinf_clicked()
{
    ui->label->setText("计算机信息");
    binfHover = false;
//    ui->butdash->setIcon(QIcon(":/PCman_RES/information_normal.png"));

    bdashHover = true;
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

    bsysConHover = true;
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

    bsoftHover = true;
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

    bhelpHover = true;

    bResHover =true;
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = true;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
    selectPage(0);
//    ui->verticalLayout_2->removeWidget(ui->verticalLayout_2->widget());
//    ui->verticalLayout_2->addWidget(sysinf);
//    ui->horizontalLayout_Widget->addWidget(sysinf);
}

void New_NavInf::on_butdash_clicked()
{
    ui->label->setText("仪表盘");
    binfHover = true;
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));

    bdashHover = false;
//    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

    bsysConHover = true;
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

    bsoftHover = true;
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

    bhelpHover = true;

    bResHover =true;
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = true;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
    selectPage(1);

//    ui->verticalLayout_2->removeWidget(ui->verticalLayout_2->widget());
//    dashboard->show();
//    ui->verticalLayout_2->addWidget(dashboard);
}

void New_NavInf::on_butsys_clicked()
{
    ui->label->setText("系统加速");
    binfHover = true;
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));

    bdashHover = true;
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

    bsysConHover = false;
//    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

    bsoftHover = true;
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

    bhelpHover = true;

    bResHover =true;
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = true;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));

    selectPage(2);

//    ui->verticalLayout_2->removeWidget(ui->verticalLayout_2->widget());
//    ui->verticalLayout_2->addWidget(syscon);
}

void New_NavInf::on_butsoft_clicked()
{

    ui->label->setText("软件管理");
    binfHover = true;
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));

    bdashHover = true;
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

    bsysConHover = true;
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

    bsoftHover = false;
//    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

    bhelpHover = true;

    bResHover =true;
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = true;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
    selectPage(3);
}

void New_NavInf::on_butres_clicked()
{
    binfHover = true;
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));

    bdashHover = true;
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

    bsysConHover = true;
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

    bsoftHover = true;
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

    bhelpHover = true;

    bResHover =false;
//    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = true;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
}

void New_NavInf::on_but360_clicked()
{
//    binfHover = true;
//    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));

//    bdashHover = true;
//    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));

//    bsysConHover = true;
//    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));

//    bsoftHover = true;
//    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));

//    bhelpHover = true;

//    bResHover =true;
//    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));

//    b360Hover = false;
//    ui->but360->setIcon(QIcon(":/PCman_RES/safe_normal.png"));
    system("nohup /opt/360sdforcnos/start360sd.sh &");
}

void New_NavInf::on_toolquit_triggered(QAction *arg1)
{

}
void New_NavInf::confirmQuit()
{
    if(QMessageBox::information(this,"提示","退出电脑管家后您的计算机将失去保护",QMessageBox::Ok,QMessageBox::Cancel)==QMessageBox::Ok)
    {
        qApp->quit();
    }

}

void New_NavInf::on_toolquit_clicked()
{
    confirmQuit();
}
void New_NavInf::mousePressEvent(QMouseEvent *event)
{


    if(event->button()==Qt::LeftButton)
    {
        isPressedWindow = true;
        offset = event->globalPos() - pos();
    }

}
void New_NavInf::mouseMoveEvent(QMouseEvent *event)
{

    if(event->buttons()&Qt::LeftButton&&isPressedWindow)
    {
        QPoint temp;
        temp = event->globalPos() - offset;
        move(temp);

//        qDebug()<<this->pos().x()<<this->pos().y()<<"\n";
    }

}

void New_NavInf::mouseReleaseEvent(QMouseEvent *event)
{
    isPressedWindow=false;
}

void New_NavInf::on_toolmin_clicked()
{
    this->hide();
}

void New_NavInf::boot()
{
    this->show();
    selectPage(2);
    syscon->setTab(1);
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));
}
void New_NavInf::uninstall()
{
    this->show();
    selectPage(3);
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_normal.png"));
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_select.png"));
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));
    soft->setTab(1);
}
void New_NavInf::closewindow()
{
    this->show();

}
void New_NavInf::clean()//用它
{
    this->show();
//    this->move(360,165);
    selectPage(2);
    syscon->setTab(0);
    ui->butsys->setIcon(QIcon(":/PCman_RES/services_select.png"));
    ui->butinf->setIcon(QIcon(":/PCman_RES/information_normal.png"));
    ui->butdash->setIcon(QIcon(":/PCman_RES/dash_normal.png"));
    ui->butsoft->setIcon(QIcon(":/PCman_RES/process_normal.png"));
    ui->butres->setIcon(QIcon(":/PCman_RES/resources_normal.png"));
}

void New_NavInf::on_toolhelp_triggered(QAction *arg1)
{

}

void New_NavInf::on_toolhelp_clicked()
{
//    ui->toolhelp->setMenu(mMenu);
    QString qtImagelFile="/usr/bin/help_doc.pdf";
    QDesktopServices::openUrl(QUrl::fromLocalFile(qtImagelFile));
//    help_about *ha = new help_about(this);
//    ha->show();
}

void New_NavInf::on_toolButton_clicked()
{
    if(ha==nullptr)
    {
        ha = new help_about(this);
        ha->show();
    }
    else
    {
        if(ha!=nullptr)
            ha->show();
    }

}
void New_NavInf::syncStartUp()
{
    mStartUp->setCheckable(true);
    QString sPATH;
    sPATH = QDir::homePath()+"/.config/autostart/";
    QDir dir(sPATH);
    QStringList nameFilters;
    nameFilters<<"*.desktop";
    QStringList slfiles = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
//    qDebug()<<slfiles;
    QString sfCon;
    bool bSup = false;
    for(int i = 0 ; i < slfiles.count();i++)
    {
        sfCon.clear();
        QFile fDesk(sPATH+slfiles[i]);
        if (fDesk.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            while (!fDesk.atEnd())
            {
                QByteArray line = fDesk.readAll();
                QString str(line);
                sfCon = str;
            }
            fDesk.close();
        }

        if(sfCon.contains("newNav_inf /hide",Qt::CaseInsensitive)&&sfCon.contains("Hidden=false",Qt::CaseInsensitive))
        {
            bSup=true;
        }

    }
    mStartUp->setChecked(bSup);
}
