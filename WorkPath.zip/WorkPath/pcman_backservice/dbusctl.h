#ifndef DBUSCTL_H
#define DBUSCTL_H

#include <QObject>

class Dbusctl : public QObject
{
    Q_OBJECT
public:
    explicit Dbusctl(QObject *parent = nullptr);

signals:

public slots:
};

#endif // DBUSCTL_H