#ifndef STARTITEM_H
#define STARTITEM_H

#include <QWidget>
#include "dialog_startup.h"

namespace Ui {
class startItem;
}

class startItem : public QWidget
{
    Q_OBJECT

public:
    explicit startItem(bool bRe ,QString sFile,QWidget *parent = nullptr);
    ~startItem();
    QString sCon;
    Dialog_startup *dia;
    QString strFILE;
    QStringList slDesk;
//    startItem *stritem;

private slots:
    void on_btnMod_clicked();

    void on_btnDel_clicked();

    void on_chkIO_stateChanged(int arg1);

private:
    Ui::startItem *ui;
};

#endif // STARTITEM_H
