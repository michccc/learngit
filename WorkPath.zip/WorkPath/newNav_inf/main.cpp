#include "new_navinf.h"
#include <QApplication>
#include <QCoreApplication>
#include <QProcess>
#include <QFile>

int main(int argc, char *argv[])
{

#if (QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QApplication a(argc, argv);
    a.desktop()->width();
    a.desktop()->height();
    a.setQuitOnLastWindowClosed(false);

    QPixmap pixmap(":/PCman_RES/splash.png");
    QSplashScreen splash(pixmap);
    QLatin1String hideOption("/hide");
    if (argc < 2 || QString(argv[1]) != hideOption)
    {
        splash.show();
    }
    //newNav_inf

    QProcess pro;
    pro.start("ps -aux");
    pro.waitForFinished();
    QString sPro = pro.readAllStandardOutput();
//    QString sUser = QDir::homePath();
    QString sUser = QDir::homePath().right(QDir::homePath().length()-6);
    QStringList slPro = sPro.split("\n");
    int ipro = 0;
    for(int i = 0 ; i < slPro.count()-1;i++)
    {
        if(slPro[i].contains("newNav_inf",Qt::CaseInsensitive)&&slPro[i].contains(sUser,Qt::CaseInsensitive))
        {
            ipro++;
        }
    }

    /*QFile fhard("/home/refreshinf");
    fhard.open(QIODevice::WriteOnly);
    fhard.close();
    while(fhard.exists())
    {

    }*/


    New_NavInf w;
    if(ipro > 1)//这个if什么时候触发
    {
        //为什么W可以取到这个stup这个类，接收端
        w.stup = new org::stup::Stup::Startup("org.stup.Stup","/stup",
                                            QDBusConnection::sessionBus(),&w);//server path session parent
        w.stup->closewindow();
//        w.close();
        return 0;
    }


    if (argc < 2 || QString(argv[1]) != hideOption)
    {
        splash.show();
        w.show();
        splash.finish(&w);

    }
    else
    {
        w.hide();
        QProcess pstart;
        pstart.startDetached("/bin/single_startup");

    }
    return a.exec();
}
