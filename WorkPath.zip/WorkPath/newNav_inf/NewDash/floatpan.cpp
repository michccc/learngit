#include "floatpan.h"
#include "ui_floatpan.h"
#include "new_navinf.h"
#include "speedyball.h"
#include "newdash.h"

static New_NavInf *ntop;
static int second1 = 0;
static int second2 = 0;
//static int w = 0;
//static int h = 0;
floatpan::floatpan(QWidget *parent, QWidget *topWindow) :
    QWidget(parent),
    ui(new Ui::floatpan)
{
    ui->setupUi(this);
    ntop = (New_NavInf*)topWindow;

//    this->setWindowFlags();
//    this->setWindowFlags(Qt::Window | Qt::CustomizeWindowHint | Qt::FramelessWindowHint);
//    this->setWindowFlags(Qt::Tool | Qt::WindowStaysOnTopHint | Qt::X11BypassWindowManagerHint);
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::Tool | Qt::WindowStaysOnTopHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
//    this->setWindowOpacity(0.6);//透明度
//    ui->allWidget->setWindowOpacity(1);//透明度

    this->setFixedHeight(400);
    this->setFixedWidth(280);
//    this->set
//    ui->btnspeed->setFixedWidth(200);
//    ui->btnspeed->setFixedHeight(86);
    ui->labeldownnum->adjustSize();
    ui->labeldownunit->adjustSize();
    ui->labelupnum->adjustSize();
    ui->labelupunit->adjustSize();
    ui->widgetup->adjustSize();
    ui->widgetDown->adjustSize();
    ui->horizontalWidget->adjustSize();
    ui->horizontalWidget_2->adjustSize();
    ui->btnspeed->setStyleSheet("border-image:url(:/PCman_RES/btn_quicken_normal.png)");
    ui->btnspeed->installEventFilter(this);
    ui->labelclose->installEventFilter(this);


    flineNetdown->setColor(QColor(31, 201, 204));
    flineNetdown->setPen(QPen(QBrush(QColor(31, 201, 204)),3,Qt::SolidLine));
    fchartNetdown->addSeries(flineNetdown);
    fchartNetdown->createDefaultAxes();
    fchartNetdown->legend()->hide();
    fchartNetdown->axisX()->hide();
    fchartNetdown->axisY()->hide();
    fchartNetdown->axisX()->setRange(0, 30);
    fchartNetdown->axisX()->setReverse(true);
    fchartNetdown->axisY()->setLabelsVisible(false);
    fchartNetdown->axisY()->setLineVisible(false);
    fchartNetdown->setMargins(QMargins(0, 8, 0, 8));
//    chartNetdown->setAnimationOptions(QChart::AllAnimations);
    fchartNetdown->setBackgroundVisible(false);
    ui->widgetDown->setChart(fchartNetdown);
    ui->widgetDown->setRenderHint(QPainter::Antialiasing);

    flineNetup->setColor(QColor(61, 204, 123));
    flineNetup->setPen(QPen(QBrush(QColor(61, 204, 123)),3,Qt::SolidLine));
    fchartNetup->addSeries(flineNetup);
    fchartNetup->createDefaultAxes();
    fchartNetup->legend()->hide();
    fchartNetup->axisX()->hide();
    fchartNetup->axisY()->hide();
    fchartNetup->axisX()->setRange(0, 30);
    fchartNetup->axisX()->setReverse(true);
    fchartNetup->axisY()->setLabelsVisible(false);
    fchartNetup->axisY()->setLineVisible(false);
    fchartNetup->setMargins(QMargins(0, 8, 0, 8));
    fchartNetup->setBackgroundVisible(false);
    ui->widgetup->setChart(fchartNetup);
    ui->widgetup->setRenderHint(QPainter::Antialiasing);


}

floatpan::~floatpan()
{
    delete ui;
}
bool floatpan::eventFilter(QObject *obj, QEvent *event)
{
     switch (event->type()) {
     case QEvent::Enter:
            if(obj==ui->btnspeed){
                ui->btnspeed->setStyleSheet("border-image:url(:/PCman_RES/btn_quicken_hover.png)");
            }
            break;
     case QEvent::Leave:
            if(obj==ui->btnspeed){
                ui->btnspeed->setStyleSheet("border-image:url(:/PCman_RES/btn_quicken_normal.png)");
            }
            break;
     case QEvent::MouseButtonPress:
         if(obj==ui->btnspeed){
             ui->btnspeed->setStyleSheet("border-image:url(:/PCman_RES/btn_quicken_pressed.png)");

         }
         if(obj==ui->labelclose){
            if(ntop->dashboard->s->smove==true&&this->fmove==true)//加速球在边界位置附近
            {
                this->hide();
                ntop->dashboard->s->move(ntop->dashboard->s->sbufPos[0],ntop->dashboard->s->sbufPos[1]);
                ntop->dashboard->s->show();
                ntop->dashboard->s->sbufPos.clear();
            }
            else
            {
                this->hide();
                ntop->dashboard->s->move(this->x(),this->y());
                ntop->dashboard->s->show();
                ntop->dashboard->s->sbufPos.clear();
                ntop->dashboard->s->smove=false;
                fmove=true;
            }
         }
            break;
     case QEvent::MouseButtonRelease:
         if(obj==ui->btnspeed){
             ui->btnspeed->setStyleSheet("border-image:url(:/PCman_RES/btn_quicken_normal.png)");
             this->hide();
         }
            break;
     default:
            break;
    }

    return QWidget::eventFilter(obj, event);
}
void floatpan::mousePressEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton)
    {
        isPressedWindow = true;
        offset = event->globalPos() - pos();
    }
}
void floatpan::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons()&Qt::LeftButton&&isPressedWindow)
    {
        QPoint temp;
        temp = event->globalPos() - offset;
        move(temp);
        fmove = false;
    }
}

void floatpan::mouseReleaseEvent(QMouseEvent *event)
{
    isPressedWindow=false;
}
void floatpan::fslCPU(qreal icpu)
{
    ui->labelCPUnum->setText(QString::number(100-icpu,'f',0));

}
void floatpan::fslMEM(qreal imem0,qreal imem1)
{
    qreal x=((imem0-imem1)/1024/1024)/((imem0)/1024/1024);
    x=x*100;
    ui->labelRAMnum->setText(QString::number(x,'f',0));
}
void floatpan::floatup(QString up)
{
    ui->labelupnum->setText(up);
}
void floatpan::floatdown(QString down)
{
    ui->labeldownnum->setText(down);
}
void floatpan::floatupunit(QString upunit)
{
    ui->labelupunit->setText(upunit);
}
void floatpan::floatdownunit(QString downunit)
{
    ui->labeldownunit->setText(downunit);
}
void floatpan::floatlineup(qreal rxtx,qreal rdownR)
{
    for (int i = 0; i < (second1 < 31 ? second1 : 31); i++)
    {
       flineNetup->replace(i, (i+1), flineNetup->at(i).y());
    }

    if(second1 > 31)
    {
        flineNetup->removePoints(31, 1);
        fchartNetup->axisY()->setRange(0, 1024);
    }
    fchartNetup->axisY()->setRange(0, rxtx);
    fchartNetup->axisY()->setLabelsVisible(false);
    fchartNetup->axisY()->setLineVisible(false);
    flineNetup->insert(0,QPointF(0,rdownR));
    ui->widgetup->repaint();
    second1++;
}
void floatpan::floatlinedown(qreal rxtx,qreal rdownR)
{

    for (int i = 0; i < (second2 < 31 ? second2 : 31); i++)
    {
       flineNetdown->replace(i, (i+1), flineNetdown->at(i).y());
    }

    if(second2 > 31)
    {
        flineNetdown->removePoints(31, 1);

    }
    qreal qrq;
//    qDebug()<<rdownR;
    if(second2%30==0)
    {
        qrq=1024;
        fchartNetdown->axisY()->setRange(0, 1024);

    }
    if(qrq<rdownR)
    {
        rxtx = qMax(rxtx,rdownR);
        qrq=rdownR;
        fchartNetdown->axisY()->setRange(0, rdownR);
    }
    fchartNetdown->axisY()->setRange(0, rxtx);


    fchartNetdown->axisY()->setLabelsVisible(false);
    fchartNetdown->axisY()->setLineVisible(false);
    flineNetdown->insert(0,QPointF(0,rdownR));
    ui->widgetDown->repaint();
    second2++;
}


void floatpan::on_btnspeed_clicked()
{

    ntop->clean();//加速功能
    if(ntop->dashboard->s->smove==true&&this->fmove==true)//加速球在边界位置附近
    {
        this->hide();
        ntop->dashboard->s->move(ntop->dashboard->s->sbufPos[0],ntop->dashboard->s->sbufPos[1]);
        ntop->dashboard->s->show();
        ntop->dashboard->s->sbufPos.clear();
    }
    else
    {
        this->hide();
        ntop->dashboard->s->move(this->x(),this->y());
        ntop->dashboard->s->show();
        ntop->dashboard->s->sbufPos.clear();
        ntop->dashboard->s->smove=false;
        fmove=true;
    }
}
