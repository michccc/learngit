#include "widget.h"
#include "ui_widget.h"
#include <QProcess>
#include <QDebug>
#include <QWidget>
#include <QPushButton>
#include <QDir>
#include <QDirIterator>
#include <QScreen>
#include <QMessageBox>
#include <QMovie>
#include <QFont>
#include <unistd.h>
#include "new_navinf.h"
//static
static New_NavInf *w;
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{

    ui->setupUi(this);
    w = (New_NavInf*)parent;
    w->syncStartUp();
    ui->stackedWidget->setCurrentIndex(1);
    ui->labclean->clear();
    ui->labcleaned->clear();
    ui->verticalLayout_5->setMargin(0);
    ui->verticalLayout_4->setMargin(0);
    ui->verticalLayout_3->setMargin(0);
    ui->horizontalLayout_3->setMargin(0);
    QScreen *screen=QGuiApplication::primaryScreen ();
    QRect mm=screen->availableGeometry() ;
    isH = mm.height();
    isW = mm.width();

    bcheck = false;

    ia=0;
    ib=0;
    ui->tableSer->insertColumn(0);
//    ui->tableSer->setColumnWidth(0,isW/(4*2));
    ui->tableSer->insertColumn(1);
    ui->tableSer->setColumnWidth(1,isW/(3*2));
    ui->tableSer->insertColumn(2);
//    ui->tableSer->setColumnWidth(2,isW/(5*2));
    ui->tableSer->insertColumn(3);
//    ui->tableSer->setColumnWidth(3,isW/(5*2));
    ui->tableSer->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
//    ui->tableSer->resizeColumnToContents(1);
    ui->tableSer->verticalHeader()->setVisible(false);
    ui->tableSer->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableSer->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableSer->setShowGrid(false);
    ui->tableSer->setFocusPolicy(Qt::NoFocus);
    QFont font ( "Noto Sans CJK SC", 13, 63);
    ui->tableSer->horizontalHeader()->setFont(font);
    ui->labbootTitle->setFont(font);
    ui->label->setFont(font);
    ui->label_2->setFont(font);
//    ui->tableSer->horizontalHeader()->setStyleSheet("QHeaderView::section{background:QColor(230, 230, 230)");
//    ui->tableSer->setMinimumWidth(isW/2);


    ui->labscan->hide();
    ui->labscaning->hide();
    ui->tablePro->insertColumn(0);
    ui->tablePro->insertColumn(1);
    ui->tablePro->insertColumn(2);
    ui->tablePro->insertColumn(3);
    ui->tablePro->insertColumn(4);
    ui->tablePro->insertColumn(5);
    ui->tablePro->horizontalHeader()->setSectionResizeMode(5, QHeaderView::Stretch);
    ui->tablePro->verticalHeader()->setVisible(false);
    ui->tablePro->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tablePro->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tablePro->setShowGrid(false);
    ui->tablePro->setFocusPolicy(Qt::NoFocus);
//    ui->tablePro->setMinimumWidth(isW/2);

//    ui->tableSer


    ui->horizontalLayout->setMargin(0);
    ui->verticalLayout->setMargin(0);
    ui->verticalLayout_2->setMargin(0);
    QStringList slHeader;
    slHeader<<"  服务名称"<<"  服务说明"<<"  启动"<<"  运行";
    ui->tableSer->setHorizontalHeaderLabels(slHeader);
    slHeader.clear();
    slHeader<<"PID"<<"占用内存"<<"内存占用率"<<"用户"<<"CPU占用率"<<"程序路径";
    ui->tablePro->setHorizontalHeaderLabels(slHeader);
    QHeaderView *header = ui->tableSer->horizontalHeader();
    QHeaderView *Proheader = ui->tablePro->horizontalHeader();
    header->setDefaultAlignment(Qt::AlignLeft);
    Proheader->setDefaultAlignment(Qt::AlignLeft);
    header->setSortIndicator(0, Qt::AscendingOrder);
    header->setSortIndicatorShown(true);
    connect(header, SIGNAL(sectionClicked(int)), ui->tableSer, SLOT (sortByColumn(int)));
    ui->tableSer->sortByColumn(0);

    Proheader->setSortIndicator(0, Qt::AscendingOrder);
    Proheader->setSortIndicatorShown(true);
    connect(Proheader, SIGNAL(sectionClicked(int)), ui->tablePro, SLOT (sortByColumn(int)));
    connect(Proheader, SIGNAL(sectionClicked(int)),this, SLOT(onHeaderClicked(int)));
    ui->tablePro->sortByColumn(0);
    //全部显示  开机启动   不开机启动   正在运行   停止运行
    QStringList slcbA;slcbA<<"全部显示"<<"正在运行"<<"停止运行";
    QStringList slcbB;slcbB<<"全部显示"<<"开机启动"<<"不开机启动";
    ui->combRun->addItems(slcbA);
    ui->comboBoot->addItems(slcbB);

    getProcess("");
    iscount = getService();
    ui->labcount->setText(QString::number(iscount));

    iCrec = -1;
    itimer = startTimer(900);

    slSave<<"[Desktop Entry]"<<"Comment=Comment"<<"Type=Application"<<"Terminal=false";
//    ui->listStartup->
    getStartup();


    bGif = false;
    ui->treeClean->setColumnCount(2);
    ui->treeClean->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    ui->treeClean->header()->setStretchLastSection(false);
    connect(ui->treeClean,SIGNAL(itemChanged(QTreeWidgetItem*,int)),this,SLOT(treeItemChanged(QTreeWidgetItem*,int)));


    ui->tablePro->horizontalHeader()->setMinimumHeight(40);
    ui->tablePro->horizontalHeader()->setMaximumHeight(40);
    ui->tableSer->horizontalHeader()->setMinimumHeight(40);
    ui->tableSer->horizontalHeader()->setMaximumHeight(40);

//    ui->tablePro->horizontalHeaderItem(0)->setTextAlignment(Qt::AlignCenter);
    //    ui->labelGif1->hide();

}

void Widget::setTab(int index)
{
    if(index<4&&index>-1)
    {
        ui->tabWidget->setCurrentIndex(index);
    }
}
int Widget::onHeaderClicked(int c)
{
    iCrec = c;
//    qDebug()<<c;
    return c;

}
Widget::~Widget()
{
    delete ui;
}
void Widget::timerEvent(QTimerEvent *event)
{
    Q_UNUSED(event);

//    ui->labp
    ui->labelPro->setText("共  "+QString::number(ui->tablePro->rowCount()));
    getProcess(ui->lineFliter->text());
//    iCrec = ui->tablePro->/*horizontalHeader*/()->sel
    if(iCrec > -1)
    {
        ui->tablePro->sortByColumn(iCrec);
    }

    QFile fDelList("/home/iok");

    if(fDelList.exists())
    {

        ui->btnClean->hide();
        ani();
//        ui->labscaning->show();
    }
    else
    {
        if(bGif == true)
        {
            ui->treeClean->clear();
            bool bClean = false;
            ui->treeClean->clear();
            QStringList nameFilters;
            nameFilters<<"*.*";
            lTbyte = 0 ;
            if(ui->checkAppCache->checkState()==Qt::Checked)
            {

                bClean = true;
                slAppcache.clear();
                lAppchache.clear();
                computClean("/home/"+sgUser+"/.cache",1,true,true);

            }
            if(ui->checkAppLog->checkState()==Qt::Checked)
            {
                bClean = true;
                slApplog.clear();
                lApplog.clear();
                computClean("/var/log",2,true,true);
            }
            if(ui->checkCrashReports->checkState()==Qt::Checked)
            {
                bClean = true;
                slCrash.clear();
                lCrash.clear();
                computClean("/var/crash",3,true,true);
            }
            if(ui->checkPackageCache->checkState()==Qt::Checked)
            {
                bClean = true;
                slPkgCache.clear();
                lPkgCache.clear();
                computClean("/var/cache/apt/archives/",4,true,true);
            }
            if(ui->checkTrash->checkState()==Qt::Checked)
            {
                bClean = true;
                slTrash.clear();
                lTrash.clear();
                computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,true);
            }

            if(bClean)
            {
                ui->stackedWidget->setCurrentIndex(0);
                ui->checkALL->setCheckState(Qt::Checked);

                ui->labTClean->setText("可清理的项目一共"+ByteconvStr(ByteTotal(lAppchache)+ByteTotal(lApplog)+ByteTotal(lCrash)+ByteTotal(lPkgCache)+ByteTotal(lTrash)));

            }
        }
        bGif = false;
        ui->labscan->hide();
        ui->btnClean->show();
    }
}
int Widget::getProcess(QString sFliter)
{
    int iPro = -1;
    QProcess pPro;

    QRegExp sep("\\s+");
    QStringList slargRam;
    slargRam<<"ax"<<"-weo"<<"pid,rss,pmem,vsize,uname:50,pcpu,start_time,state,group,nice,cputime,session,cmd"<<"--no-headings";
    try
    {
        QStringList slPro;

        pPro.start("ps",slargRam);
        pPro.waitForFinished();
        slPro.clear();
        slPro = QString(pPro.readAllStandardOutput()).trimmed().split('\n');

        iPro = slPro.count();

        ui->tablePro->clearContents();
        ui->tablePro->setRowCount(0);
        for(int r = 0 ; r< slPro.count();r++)
        {

            QStringList sl = slPro[r].trimmed().split(sep);
            QString s11;
            for(int i = 12; i < sl.count();i++)
            {
                s11=s11+" "+sl[i];
            }

            bool bUp = true;

            if(bUp)
            {
                ui->tablePro->insertRow(r);
                QTableWidgetItem *item0 = new QTableWidgetItem();
                item0->setData(Qt::DisplayRole, sl[0].toInt());
                QTableWidgetItem *item1 = new QTableWidgetItem();
                item1->setData(Qt::DisplayRole, sl[1].toDouble()/1024);
                QTableWidgetItem *item2 = new QTableWidgetItem();
                item2->setData(Qt::DisplayRole, sl[5].toDouble());
                item0->setBackground(Qt::green);
//                item0->setBackgroundColor(QColor(182,190,233));
                ui->tablePro->setItem(r,0,item0);//PID
                ui->tablePro->setItem(r,1,item1);//new QTableWidgetItem(QString::number(sl[1].toDouble()/1024,'f',2)+"MB"));//mem
                ui->tablePro->setItem(r,2,new QTableWidgetItem(sl[2]));//mem par
                ui->tablePro->setItem(r,3,new QTableWidgetItem(sl[4]));//user
                ui->tablePro->setItem(r,4,item2);//cpu
                ui->tablePro->setItem(r,5,new QTableWidgetItem(s11));//loc
                ui->tablePro->item(r,0)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(r,1)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(r,2)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(r,3)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(r,4)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(r,5)->setTextColor(QColor(1,1,1));
            }
            if(!s11.contains(sFliter,Qt::CaseInsensitive)&&sFliter!="")
            {
                ui->tablePro->hideRow(r);
            }
            if(sl[0] == recPID)
            {
//                ui->tablePro->item(r,0)->setBackground(QBrush(QColor(182,190,233)));
//                ui->tablePro->item(r,0)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->item(r,0)->setBackgroundColor(QColor(182,190,233));
                ui->tablePro->item(r,0)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(r,1)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(r,2)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(r,3)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(r,4)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(r,5)->setTextColor(QColor(72,92,200));
//                ui->tablePro->item(r,1)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->item(r,2)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->item(r,3)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->item(r,4)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->item(r,5)->setBackgroundColor(QColor(182,190,233));
//                ui->tablePro->selectRow(r);
            }
//            ui->tablePro->setColumnWidth(0, wide);
            ui->tablePro->setRowHeight(r, 40);
        }

    }
    catch(QString &ex)
    {
            qCritical() << ex;
    }


    return iPro;
}
int Widget::getService()
{
    serviceList.clear();

    int iSer = -1;
    QProcess pSer;
    try {

        QStringList args = { "list-unit-files", "-t", "service", "-a", "--state=enabled,disabled" };
        pSer.start("systemctl", args);
        pSer.waitForFinished();
        QStringList lines = QString(pSer.readAllStandardOutput()).split('\n').filter(QRegExp("[^@].service"));
        QRegExp sep("\\s+");
        iSer = lines.count();
        int r = 0;
        for (const QString &line : lines)
        {

            stService stS;
            stS.clear();
            QStringList s = line.trimmed().split(sep);
            QString name = s.first().trimmed().replace(".service", "");


            args.clear();
            args<<"cat"<<name;
            pSer.start("systemctl",args);
            pSer.waitForFinished();
            QStringList sldescription = QString(pSer.readAllStandardOutput()).split('\n').filter(QRegExp("^Description"));
            QString sdescription;
            if(sldescription.count()>0)
                sdescription=sldescription.first().replace("Description=","");
            bool bstatus = ! s.last().trimmed().compare("enabled");

            args.clear();
            args<<"is-active"<<name;
            pSer.start("systemctl",args);
            pSer.waitForFinished();
            QString sact = QString(pSer.readAllStandardOutput()).trimmed();
            bool bact = ! sact.compare("active");

            stS.bEnable = bstatus;
            stS.sDes = sdescription;
            stS.sSer = name;
            stS.bAct = bact;
            serviceList.append(stS);
            QTableWidgetItem *twName = new QTableWidgetItem();
            twName->setText(name);
            ui->tableSer->insertRow(r);
            ui->tableSer->setItem(r,0,twName);
            ui->tableSer->setItem(r,1,new QTableWidgetItem(sdescription));
            if (bstatus)
            {
                ui->tableSer->setItem(r,2,new QTableWidgetItem("开机启动"));
            }
            else
            {
                ui->tableSer->setItem(r,2,new QTableWidgetItem("不开机启动"));
            }
            if (bact)
            {
                ui->tableSer->setItem(r,3,new QTableWidgetItem("正在运行"));
            }
            else
            {
                ui->tableSer->setItem(r,3,new QTableWidgetItem("停止运行"));
            }
            ui->tableSer->setRowHeight(r, 40);
            r++;
        }

    } catch(QString &ex) {
        qCritical() << ex;
    }
    return  iSer;
}

void Widget::on_comboBoot_currentIndexChanged(int index)
{
    ib = index;
    reserTab();
}

void Widget::on_combRun_currentIndexChanged(int index)
{
    ia = index;
    reserTab();
}
void Widget::reserTab()
{
    //全部显示  开机启动   不开机启动   正在运行   停止运行
    int icurr = iscount;
    for(int i = 0 ; i < ui->tableSer->rowCount();i++)
    {
        ui->tableSer->showRow(i);
        bool bJ =false;
        if(ui->tableSer->item(i,3)!=nullptr&&ui->tableSer->item(i,2)!=nullptr)
        {

            if(ui->tableSer->item(i,3)->text()=="停止运行")
            {
                if(ia == 1)
                {

                    ui->tableSer->hideRow(i);

                    if(!bJ)
                    {
                        bJ=true;
                        icurr--;
                    }
                }

            }
            else
            {
                if(ia == 2)
                {
                    ui->tableSer->hideRow(i);

                    if(!bJ)
                    {
                        bJ=true;
                        icurr--;
                    }
                }
            }
            if(ui->tableSer->item(i,2)->text()=="不开机启动")
            {
                if(ib == 1)
                {
                    ui->tableSer->hideRow(i);

                    if(!bJ)
                    {
                        bJ=true;
                        icurr--;
                    }
                }

            }
            else
            {
                if(ib == 2)
                {
                    ui->tableSer->hideRow(i);

                    if(!bJ)
                    {
                        bJ=true;
                        icurr--;
                    }
                }
            }

        }

    }
    ui->labcount->setText(QString::number(icurr));
}


void Widget::on_tablePro_cellClicked(int row, int column)
{
    Q_UNUSED(column);

    killTimer(itimer);
    for(int ic=0 ; ic < ui->tablePro->rowCount();ic++)
    {
        if(ui->tablePro->item(ic,0)!=nullptr)
        {
            if(ui->tablePro->item(ic,0)->text()==recPID)
            {
                ui->tablePro->item(ic,0)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(ic,1)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(ic,2)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(ic,3)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(ic,4)->setTextColor(QColor(72,92,200));
                ui->tablePro->item(ic,5)->setTextColor(QColor(72,92,200));
            }
            else
            {
                ui->tablePro->item(ic,0)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(ic,1)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(ic,2)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(ic,3)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(ic,4)->setTextColor(QColor(1,1,1));
                ui->tablePro->item(ic,5)->setTextColor(QColor(1,1,1));
            }
        }
    }

    recPID = ui->tablePro->item(row,0)->text();
    itimer = startTimer(1000);
//    qDebug()<<recPID;
}

void Widget::on_BtnKill_clicked()
{
    if(recPID!="")
    {
//        sgUser="";
//        QFile fDelList("/home/"+sgUser+"/.celanList.txt");
        QFile fKillList("/home/io");
//        QFile fUnsList("/home/"+sgUser+"/.UnsList.txt");
//        fDelList.open(QIODevice::WriteOnly);
//        fDelList.close();
        fKillList.open(QIODevice::WriteOnly);
        fKillList.close();
//        fUnsList.open(QIODevice::WriteOnly);
//        fUnsList.close();
        if(fKillList.open(QIODevice::ReadWrite | QIODevice::Text))
        {
            QTextStream stream(&fKillList);
            stream.seek(fKillList.size());
            stream<<recPID;
            fKillList.close();
        }

    }
//    if(recPID!="")
//    {
//        QProcess pKill;
//        pKill.start("kill -9 "+recPID);
//        pKill.waitForFinished();
//        pKill.close();
//    }
}

int Widget::getStartup()
{
    ui->listStartup->clear();
    lStartUp.clear();
    QRegExp sep("\\s+");
    QProcess pUser;
    pUser.start("w");
    pUser.waitForFinished();
    QString sUser = QString(pUser.readAllStandardOutput().trimmed()).split('\n')[2].split(sep)[0].trimmed();
    sPATH.clear();
    sPATH = QDir::homePath()+"/.config/autostart/";

    sgUser = QDir::homePath().right(QDir::homePath().length()-6);
    QDir dir(sPATH);
    QStringList nameFilters;
    nameFilters<<"*.desktop";
    QStringList slfiles = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
//    qDebug()<<slfiles;
    for(int i = 0 ; i < slfiles.count();i++)
    {
        startItem *stI = new startItem(true,sPATH+slfiles[i],this);
        qDebug()<<sPATH+slfiles[i];
        lStartUp.append(stI);
        QListWidgetItem* listitem = new QListWidgetItem;
//        listitem->setFlags(Qt::NoItemFlags);
        listitem->setSizeHint(QSize(isW*0.46,isH*0.048));
        ui->listStartup->addItem(listitem);
        ui->listStartup->setItemWidget(listitem,stI);

    }
    return ui->listStartup->count();
}

void Widget::on_pushButton_add_clicked()
{
    Dialog_startup *dia = new Dialog_startup(sPATH,this);

    dia->show();
}

void Widget::saveStartup(QString sPath ,QString sEXEc,QString sHide ,QString sName)
{
    slSave.clear();
//    qDebug()<<sPath;
    slSave<<"[Desktop Entry]"<<"Comment=Comment"<<"Type=Application"<<"Terminal=false";
    QFile saveP(sPath);
    saveP.open(QIODevice::WriteOnly);
    saveP.close();
    if(saveP.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&saveP);
        stream.seek(saveP.size());
        slSave.insert(1,sName);
        slSave.insert(1,sEXEc);
        slSave.insert(1,sHide);
        for(int i =0;i<slSave.count();i++)
        {
            stream<<slSave[i]<<"\n";
        }
        if (sEXEc.contains("newNav_inf",Qt::CaseInsensitive))
        {
                stream<<"Icon=/usr/share/logo.png";

        }

        saveP.close();
    }
    w->syncStartUp();
}

void Widget::on_btnScan_clicked()
{
//    ui->btnScan->hide();


    if(ui->checkSelectAllSystemScan->checkState()!=Qt::Unchecked||ui->checkAppCache->checkState()==Qt::Checked||ui->checkAppLog->checkState()==Qt::Checked
            ||ui->checkCrashReports->checkState()==Qt::Checked||ui->checkPackageCache->checkState()==Qt::Checked||ui->checkTrash->checkState()==Qt::Checked)
    {
        lAppchache.clear();
        lApplog.clear();
        lCrash.clear();
        lTrash.clear();
        lPkgCache.clear();
        ui->btnScan->hide();
//        ani();
        bool bClean = false;
        ui->treeClean->clear();
        ltClean.clear();
        QStringList nameFilters;
        nameFilters<<"*.*";
        lTbyte = 0 ;
        if(ui->checkAppCache->checkState()==Qt::Checked)
        {

            bClean = true;
            slAppcache.clear();
            lAppchache.clear();
            computClean("/home/"+sgUser+"/.cache",1,true,true);

        }
        if(ui->checkAppLog->checkState()==Qt::Checked)
        {
            bClean = true;
            slApplog.clear();
            lApplog.clear();
            computClean("/var/log",2,true,true);
        }
        if(ui->checkCrashReports->checkState()==Qt::Checked)
        {
            bClean = true;
            slCrash.clear();
            lCrash.clear();
            computClean("/var/crash",3,true,true);
        }
        if(ui->checkPackageCache->checkState()==Qt::Checked)
        {
            bClean = true;
            slPkgCache.clear();
            lPkgCache.clear();
            computClean("/var/cache/apt/archives/",4,true,true);
        }
        if(ui->checkTrash->checkState()==Qt::Checked)
        {
            bClean = true;
            slTrash.clear();
            lTrash.clear();
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,true);
        }

        if(bClean)
        {
            ui->stackedWidget->setCurrentIndex(0);
            ui->checkALL->setCheckState(Qt::Checked);

            ui->labTClean->setText("");
            ui->labTClean->setText("可清理的项目一共"+ByteconvStr(ByteTotal(lAppchache)+ByteTotal(lApplog)+ByteTotal(lCrash)+ByteTotal(lPkgCache)+ByteTotal(lTrash)));

        }
        ui->btnScan->show();
        ui->labscan->hide();

    }
    else
    {
        ui->btnScan->show();
        ui->labscan->hide();
        QMessageBox::information(this,"小心","您没有选择任何可清理的项目,请仔细检查");

    }
//    sleep(1);
//    QtConcurrent::run(this, &Widget::datasacn);
}
double Widget::ByteTotal(QList<long long> listL)
{
    double il = 0;
    for(int l = 0 ; l < listL.count();l++)
    {
        il = il+listL[l];
    }
    return  il;
}

void Widget::changecheck()
{
    if(ui->checkAppCache->checkState()==Qt::Checked&&ui->checkAppLog->checkState()==Qt::Checked
      &&ui->checkCrashReports->checkState()==Qt::Checked&&ui->checkPackageCache->checkState()==Qt::Checked
      &&ui->checkTrash->checkState()==Qt::Checked)
    {
        ui->checkSelectAllSystemScan->setCheckState(Qt::Checked);
    }
    if(ui->checkAppCache->checkState()==Qt::Unchecked||ui->checkAppLog->checkState()==Qt::Unchecked
      ||ui->checkCrashReports->checkState()==Qt::Unchecked||ui->checkPackageCache->checkState()==Qt::Unchecked
      ||ui->checkTrash->checkState()==Qt::Unchecked)
    {
        if(!bcheck)
        {
            ui->checkSelectAllSystemScan->setCheckState(Qt::PartiallyChecked);
        }

    }
    if(ui->checkAppCache->checkState()==Qt::Unchecked&&ui->checkAppLog->checkState()==Qt::Unchecked
      &&ui->checkCrashReports->checkState()==Qt::Unchecked&&ui->checkPackageCache->checkState()==Qt::Unchecked
      &&ui->checkTrash->checkState()==Qt::Unchecked)
    {
        ui->checkSelectAllSystemScan->setCheckState(Qt::Unchecked);
    }
//    bcheck=false;

}

void Widget::on_checkSelectAllSystemScan_stateChanged(int arg1)
{
    Q_UNUSED(arg1);


}

void Widget::computClean(QString sDir, int i , bool bChk,bool bScan)
{

    QDir dir(sDir);
    long long lt = 0;
    QStringList slDir;
    QStringList slFile;
    QStringList sl;
    QList<long long> ll;
    if(bScan)
    {
        if(i!=4)
        {
            slDir= dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
            for(int id = 0 ; id<slDir.count();id++)
            {   long long lfSize = 0;
                QDirIterator dir_iterator(sDir+"/"+slDir[id],QDir::Files,QDirIterator::Subdirectories);
                while(dir_iterator.hasNext())
                {
                   dir_iterator.next();
                   QFileInfo file_info = dir_iterator.fileInfo();
                   QString absolute_file_path = file_info.absoluteFilePath();
                   QFileInfo info(absolute_file_path);
                   lfSize = info.size()+lfSize;
                }
                lt = lfSize + lt;
//                lTbyte = lt+lTbyte;
                ll.append(lfSize);
            }
            sl<<slDir;
        }

        slFile = dir.entryList(QDir::Files);
        for(int id = 0 ; id<slFile.count();id++)
        {
            long long lfSize = 0;
            QFileInfo info(sDir+"/"+slFile[id]);
            lfSize = info.size();
            ll.append(lfSize);
            lt = lfSize + lt;
//            lTbyte = +lTbyte;
        }
        sl<<slFile;

    }

    QString sSize = ByteconvStr(lt);
    if(i == 1)
    {
        if(bScan)
        {
            slAppcache = sl;
            lAppchache =ll;
        }
        else
        {
            long ltmp=0;
            for(int i = 0; i < lAppchache.count();i++)
            {
                ltmp=lAppchache[i]+ltmp;
            }
            sSize = ByteconvStr(ltmp);
        }


        QTreeWidgetItem *qTreeAppcache = new QTreeWidgetItem();
        QList <QTreeWidgetItem*> ltc;
        qTreeAppcache->setText(0,"程序缓存");
        qTreeAppcache->setText(1,sSize);
        qTreeAppcache->setFlags(qTreeAppcache->flags()|Qt::ItemIsUserCheckable);
        if(bChk)
            qTreeAppcache->setCheckState(0,Qt::Checked);
        else
            qTreeAppcache->setCheckState(0,Qt::Unchecked);
        for(int i = 0 ; i < slAppcache.count() ; i++)
        {
            QTreeWidgetItem *qTreeC = new QTreeWidgetItem();
            qTreeC->setText(0,slAppcache[i]);
            qTreeC->setText(1,ByteconvStr(lAppchache[i]));
            qTreeC->setFlags(qTreeC->flags()|Qt::ItemIsUserCheckable);
            if(bChk)
                qTreeC->setCheckState(0,Qt::Checked);
            else
                qTreeC->setCheckState(0,Qt::Unchecked);
            ltc.append(qTreeC);
        }
        qTreeAppcache->addChildren(ltc);
        ui->treeClean->addTopLevelItem(qTreeAppcache);
    }
    if(i == 2)
    {
        if(bScan)
        {
            slApplog = sl;
            lApplog =ll;
        }
        else
        {
            long ltmp=0;
            for(int i = 0; i < lApplog.count();i++)
            {
                ltmp=lApplog[i]+ltmp;
            }
            sSize = ByteconvStr(ltmp);
        }

        QTreeWidgetItem *qTreeApplog = new QTreeWidgetItem();
        QList <QTreeWidgetItem*> ltc;
        qTreeApplog->setText(0,"程序日志");
        qTreeApplog->setText(1,sSize);
        qTreeApplog->setFlags(qTreeApplog->flags()|Qt::ItemIsUserCheckable);
        if(bChk)
            qTreeApplog->setCheckState(0,Qt::Checked);
        else
            qTreeApplog->setCheckState(0,Qt::Unchecked);
        for(int i = 0 ; i < slApplog.count() ; i++)
        {
            QTreeWidgetItem *qTreeC = new QTreeWidgetItem();
            qTreeC->setText(0,slApplog[i]);
            qTreeC->setText(1,ByteconvStr(lApplog[i]));
            qTreeC->setFlags(qTreeC->flags()|Qt::ItemIsUserCheckable);
            if(bChk)
                qTreeC->setCheckState(0,Qt::Checked);
            else
                qTreeC->setCheckState(0,Qt::Unchecked);
            ltc.append(qTreeC);
        }
        qTreeApplog->addChildren(ltc);
        ui->treeClean->addTopLevelItem(qTreeApplog);
    }
    if(i == 3)
    {
        if(bScan)
        {
            slCrash = sl;
            lCrash =ll;
        }
        else
        {
            long ltmp=0;
            for(int i = 0; i < lCrash.count();i++)
            {
                ltmp=lCrash[i]+ltmp;
            }
            sSize = ByteconvStr(ltmp);
        }

        QTreeWidgetItem *qTreeCrash = new QTreeWidgetItem();
        QList <QTreeWidgetItem*> ltc;
        qTreeCrash->setText(0,"崩溃日志");
        qTreeCrash->setText(1,sSize);
        qTreeCrash->setFlags(qTreeCrash->flags()|Qt::ItemIsUserCheckable);
        if(bChk)
            qTreeCrash->setCheckState(0,Qt::Checked);
        else
            qTreeCrash->setCheckState(0,Qt::Unchecked);
        for(int i = 0 ; i < slCrash.count() ; i++)
        {
            QTreeWidgetItem *qTreeC = new QTreeWidgetItem();
            qTreeC->setText(0,slCrash[i]);
            qTreeC->setText(1,ByteconvStr(lCrash[i]));
            qTreeC->setFlags(qTreeC->flags()|Qt::ItemIsUserCheckable);
            if(bChk)
                qTreeC->setCheckState(0,Qt::Checked);
            else
                qTreeC->setCheckState(0,Qt::Unchecked);
            ltc.append(qTreeC);
        }
        qTreeCrash->addChildren(ltc);
        ui->treeClean->addTopLevelItem(qTreeCrash);
    }
    if(i == 4)
    {
        if(bScan)
        {
            slPkgCache = sl;
            lPkgCache =ll;
        }
        else
        {
            long ltmp=0;
            for(int i = 0; i < lPkgCache.count();i++)
            {
                ltmp=lPkgCache[i]+ltmp;
            }
            sSize = ByteconvStr(ltmp);
        }


        QTreeWidgetItem *qTreePkgCache = new QTreeWidgetItem();
        QList <QTreeWidgetItem*> ltc;
        qTreePkgCache->setText(0,"包缓存");
        qTreePkgCache->setText(1,sSize);
        qTreePkgCache->setFlags(qTreePkgCache->flags()|Qt::ItemIsUserCheckable);
        if(bChk)
            qTreePkgCache->setCheckState(0,Qt::Checked);
        else
            qTreePkgCache->setCheckState(0,Qt::Unchecked);
        for(int i = 0 ; i < slPkgCache.count() ; i++)
        {
            QTreeWidgetItem *qTreeC = new QTreeWidgetItem();
            qTreeC->setText(0,slPkgCache[i]);
            qTreeC->setText(1,ByteconvStr(lPkgCache[i]));
            qTreeC->setFlags(qTreeC->flags()|Qt::ItemIsUserCheckable);
            if(bChk)
                qTreeC->setCheckState(0,Qt::Checked);
            else
                qTreeC->setCheckState(0,Qt::Unchecked);
            ltc.append(qTreeC);
        }
        qTreePkgCache->addChildren(ltc);
        ui->treeClean->addTopLevelItem(qTreePkgCache);
    }
    if(i == 5)
    {
        if(bScan)
        {
            slTrash= sl;
            lTrash =ll;
        }
        else
        {
            long ltmp=0;
            for(int i = 0; i < lTrash.count();i++)
            {
                ltmp=lTrash[i]+ltmp;
            }
            sSize = ByteconvStr(ltmp);
        }


        QTreeWidgetItem *qTreeTrash = new QTreeWidgetItem();
        QList <QTreeWidgetItem*> ltc;
        qTreeTrash->setText(0,"回收站");
        qTreeTrash->setText(1,sSize);
        qTreeTrash->setFlags(qTreeTrash->flags()|Qt::ItemIsUserCheckable);
        if(bChk)
            qTreeTrash->setCheckState(0,Qt::Checked);
        else
            qTreeTrash->setCheckState(0,Qt::Unchecked);
        ui->treeClean->addTopLevelItem(qTreeTrash);
    }

//    qDebug()<<slTrash.count()<<slPkgCache.count()<<slCrash.count()<<slAppcache.count()<<slApplog.count();
//    qDebug()<<(double)lt/1024/1024/1024<<slAppcache<<lAppchache;
}

QString Widget::ByteconvStr(double llb)
{
    QString strR;
    if(llb<KB)
    {
        strR = QString::number(llb,'f',2)+"Bytes";
    }
    else if(llb<MB)
    {
        strR = QString::number(llb/KB,'f',2)+"KB";
    }
    else if(llb<GB)
    {
        strR = QString::number(llb/MB,'f',2)+"MB";
    }
    else if(llb<TB)
    {
        strR = QString::number(llb/GB,'f',2)+"GB";
    }
    else
    {
        strR = QString::number(llb/TB,'f',2)+"TB";
    }
    return  strR;
}
void Widget::treeItemChanged(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);
    bReTREE = true;
    if(bReTREE)
    {
        QString itemText = item->text(0);
        if (item->checkState(0) == Qt::Checked)
            {
            QTreeWidgetItem *parent = item->parent();
            Q_UNUSED(parent);
            int cnt = item->childCount();
            if (cnt >0)
                {
                for (int i = 0;i < cnt;i++)
                    {
                     item->child(i)->setCheckState(0,Qt::Checked);
                }
            }
            else
                {
                updateParentItem(item);
            }
        }
        else if (item->checkState(0) == Qt::Unchecked)
            {
            int cnt = item->childCount();
            if (cnt > 0)
                {
                for (int i = 0;i < cnt;i++)
                    {
                    item->child(i)->setCheckState(0,Qt::Unchecked);
                }
            }
            else
                {
                updateParentItem(item);
            }
        }
        QTreeWidgetItemIterator it(ui->treeClean);
        bool ball = true;
        int ibc = 0;
        int ic = 0;
        while (*it)
        {
            if((*it)->checkState(0)==Qt::Checked)
            {
                ball = false;
                ibc ++;
            }
            ic++;
            ++it;
        }
        if(ibc == ic)
        {
            ui->checkALL->setCheckState(Qt::Checked);
        }
        if(ibc < ic)
        {
            ui->checkALL->setCheckState(Qt::PartiallyChecked);
        }
        if(ibc ==0)
        {
            ui->checkALL->setCheckState(Qt::Unchecked);
        }
    }

}

void Widget::updateParentItem(QTreeWidgetItem *item)
{
    QTreeWidgetItem *parent = item->parent();
    if (parent == nullptr)
    {
       return;
    }
    //选中的子节点个数
    int selectedCount = 0;
    int childCount = parent->childCount();
    for (int i = 0; i < childCount; i++)
    {
       QTreeWidgetItem *childItem = parent->child(i);
       if (childItem->checkState(0) == Qt::Checked)
       {
        selectedCount++;
       }
    }
    if (selectedCount <= 0)
    {
        //未选中状态
       parent->setCheckState(0, Qt::Unchecked);
//       ui->checkALL->setCheckState(Qt::Unchecked);
    }
    else if (selectedCount > 0 && selectedCount < childCount)
    {
       //部分选中状态
       parent->setCheckState(0, Qt::PartiallyChecked);
//       ui->checkALL->setCheckState(Qt::Unchecked);
    }
    else if (selectedCount == childCount)
    {
      //选中状态
       parent->setCheckState(0, Qt::Checked);
    }


}

void Widget::on_btnClean_clicked()
{
//    ui->btnClean->hide();
//    ui->btnClean->setStyleSheet("border-image: url(:/PCman_RES/cleanning.png)");
    if(ui->checkALL->checkState()!=Qt::Unchecked)
    {
        bGif = true;
        ui->btnClean->hide();
        ani();
//        ui->labscaning->show();
        QStringList slDel;
        long lDel = 0;
        slDel.clear();
        QTreeWidgetItemIterator it(ui->treeClean);
        while (*it)
        {
            if((*it)->parent()!=nullptr&&(*it)->checkState(0)==Qt::Checked&& (*it)->text(0)!="回收站" )
            {
                if((*it)->parent()->text(0)=="程序缓存")
                {
                    slDel.append("/home/"+sgUser+"/.cache/"+(*it)->text(0));

                }


                if((*it)->parent()->text(0)=="程序日志")
                {
                    slDel.append("/var/log/"+(*it)->text(0));
                }


                if((*it)->parent()->text(0)=="崩溃日志")
                {
                    slDel.append("/var/crash/"+(*it)->text(0));
                }


                if((*it)->parent()->text(0)=="包缓存")
                {
                    slDel.append("/var/cache/apt/archives/"+(*it)->text(0));
                }

            }

            if((*it)->parent()==nullptr&&(*it)->checkState(0)==Qt::Checked && (*it)->text(0)=="回收站" )
            {
                for(int nt = 0 ; nt < slTrash.count();nt++)
                {
                    slDel.append("/home/"+sgUser+"/.local/share/Trash/"+slTrash[nt]);
                }

            }

            ++it;
        }



//        sgUser="";
        QFile fDelList("/home/iok");
//        QFile fKillList("/home/"+sgUser+"/.KillList.txt");
//        QFile fUnsList("/home/"+sgUser+"/.UnsList.txt");
        fDelList.open(QIODevice::WriteOnly);
        fDelList.close();
//        fKillList.open(QIODevice::WriteOnly);
//        fKillList.close();
//        fUnsList.open(QIODevice::WriteOnly);
//        fUnsList.close();
        if(fDelList.open(QIODevice::ReadWrite | QIODevice::Text))
        {
            QTextStream stream(&fDelList);
            stream.seek(fDelList.size());
            for (int d = 0 ; d < slDel.count() ; d++)
            {
                stream<<slDel[d]<<'\n';
            }
            fDelList.close();
        }
        for(int idel = 0 ; idel < slDel.count();idel++)
        {
            QFile df(slDel[idel]);
            QDir dd(slDel[idel]);

            if(df.exists())
            {
                lDel = lDel + df.size();
            }
            if(dd.exists())
            {
                lDel = lDel + dirFileSize(dd.path());
            }
        }

        ui->treeClean->clear();
        bool bClean = false;
        ui->treeClean->clear();
        QStringList nameFilters;
        nameFilters<<"*.*";
        lTbyte = 0 ;
        if(ui->checkAppCache->checkState()==Qt::Checked)
        {

            bClean = true;
            slAppcache.clear();
            lAppchache.clear();
            computClean("/home/"+sgUser+"/.cache",1,true,true);

        }
        if(ui->checkAppLog->checkState()==Qt::Checked)
        {
            bClean = true;
            slApplog.clear();
            lApplog.clear();
            computClean("/var/log",2,true,true);
        }
        if(ui->checkCrashReports->checkState()==Qt::Checked)
        {
            bClean = true;
            slCrash.clear();
            lCrash.clear();
            computClean("/var/crash",3,true,true);
        }
        if(ui->checkPackageCache->checkState()==Qt::Checked)
        {
            bClean = true;
            slPkgCache.clear();
            lPkgCache.clear();
            computClean("/var/cache/apt/archives/",4,true,true);
        }
        if(ui->checkTrash->checkState()==Qt::Checked)
        {
            bClean = true;
            slTrash.clear();
            lTrash.clear();
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,true);
        }

        if(bClean)
        {
            ui->stackedWidget->setCurrentIndex(0);
            ui->checkALL->setCheckState(Qt::Checked);

            ui->labTClean->setText("可清理的项目一共"+ByteconvStr(ByteTotal(lAppchache)+ByteTotal(lApplog)+ByteTotal(lCrash)+ByteTotal(lPkgCache)+ByteTotal(lTrash)));

        }
        ui->labcleaned->setText("本次已经清理 "+ByteconvStr((double)lDel));
//        ui->btnClean->show();
//        ui->labscaning->hide();

    }
    else
    {
        QMessageBox::information(this,"注意","您还没有选择任何可清理的项目,请选择后再进行清理");
    }


}
quint64 Widget::dirFileSize(const QString &path)
{
    QDir dir(path);
    long long size = 0;
    //dir.entryInfoList(QDir::Files)返回文件信息
    foreach(QFileInfo fileInfo, dir.entryInfoList(QDir::Files))
    {
        //计算文件大小
        size += fileInfo.size();
    }
    //dir.entryList(QDir::Dirs|QDir::NoDotAndDotDot)返回所有子目录，并进行过滤
    foreach(QString subDir, dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot))
    {
        //若存在子目录，则递归调用dirFileSize()函数
        size += dirFileSize(path + QDir::separator() + subDir);
    }
    return size;
}

void Widget::on_checkALL_clicked()
{

    bReTREE = false;
    if(ui->checkALL->checkState()==Qt::Checked&&!bReTREE)
    {
//        ui->checkALL->setCheckState(Qt::Unchecked);
        ui->treeClean->clear();
        bReTREE = true;
//        if(slAppcache.count()>0)
        if(ui->checkAppCache->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.cache",1,true,false);
        //        if(slApplog.count()>0)
        if(ui->checkAppLog->checkState()==Qt::Checked)
            computClean("/var/log",2,true,false);
        //        if(slCrash.count()>0)
        if(ui->checkCrashReports->checkState()==Qt::Checked)
            computClean("/var/crash",3,true,false);
        //        if(slPkgCache.count()>0)
        if(ui->checkPackageCache->checkState()==Qt::Checked)
            computClean("/var/cache/apt/archives/",4,true,false);
        //        if(slTrash.count()>0)
        if(ui->checkTrash->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,false);

    }
    if(ui->checkALL->checkState()==Qt::Unchecked&&!bReTREE)
    {
//        ui->checkALL->setCheckState(Qt::Checked);
        ui->treeClean->clear();
        bReTREE = true;
        if(ui->checkAppCache->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.cache",1,false,false);
        if(ui->checkAppLog->checkState()==Qt::Checked)
            computClean("/var/log",2,false,false);
        if(ui->checkCrashReports->checkState()==Qt::Checked)
            computClean("/var/crash",3,false,false);
        if(ui->checkPackageCache->checkState()==Qt::Checked)
            computClean("/var/cache/apt/archives/",4,false,false);
        if(ui->checkTrash->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,false,false);

    }
    if(ui->checkALL->checkState()==Qt::PartiallyChecked&&!bReTREE)
    {
        ui->checkALL->setCheckState(Qt::Checked);
        ui->treeClean->clear();
        bReTREE = true;
        if(ui->checkAppCache->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.cache",1,true,false);
        if(ui->checkAppLog->checkState()==Qt::Checked)
            computClean("/var/log",2,true,false);
        if(ui->checkCrashReports->checkState()==Qt::Checked)
            computClean("/var/crash",3,true,false);
        if(ui->checkPackageCache->checkState()==Qt::Checked)
            computClean("/var/cache/apt/archives/",4,true,false);
        if(ui->checkTrash->checkState()==Qt::Checked)
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,false);

        bReTREE = true;
    }
}

void Widget::on_pushButton_clicked()
{
    ui->labcleaned->setText("");
    ui->stackedWidget->setCurrentIndex(1);
}
void Widget::ani()
{
    QMovie *movie1 = new QMovie(":/PCman_RES/cleanning.gif");
    QMovie *movie0 = new QMovie(":/PCman_RES/scanning.gif");
    ui->labscan->setMovie(movie1);
    movie0->start();
    ui->labscaning->setMovie(movie0);
    movie1->start();
    ui->labscan->show();
//    ui->labscaning->show();
//    sleep(3);
}

void Widget::datasacn()
{
    if(ui->checkSelectAllSystemScan->checkState()!=Qt::Unchecked||ui->checkAppCache->checkState()==Qt::Checked||ui->checkAppLog->checkState()==Qt::Checked
            ||ui->checkCrashReports->checkState()==Qt::Checked||ui->checkPackageCache->checkState()==Qt::Checked||ui->checkTrash->checkState()==Qt::Checked)
    {

//        ani();
        bool bClean = false;
        ui->treeClean->clear();
        ltClean.clear();
        QStringList nameFilters;
        nameFilters<<"*.*";
        lTbyte = 0 ;
        if(ui->checkAppCache->checkState()==Qt::Checked)
        {

            bClean = true;
            slAppcache.clear();
            lAppchache.clear();
            computClean("/home/"+sgUser+"/.cache",1,true,true);

        }
        if(ui->checkAppLog->checkState()==Qt::Checked)
        {
            bClean = true;
            slApplog.clear();
            lApplog.clear();
            computClean("/var/log",2,true,true);
        }
        if(ui->checkCrashReports->checkState()==Qt::Checked)
        {
            bClean = true;
            slCrash.clear();
            lCrash.clear();
            computClean("/var/crash",3,true,true);
        }
        if(ui->checkPackageCache->checkState()==Qt::Checked)
        {
            bClean = true;
            slPkgCache.clear();
            lPkgCache.clear();
            computClean("/var/cache/apt/archives/",4,true,true);
        }
        if(ui->checkTrash->checkState()==Qt::Checked)
        {
            bClean = true;
            slTrash.clear();
            lTrash.clear();
            computClean("/home/"+sgUser+"/.local/share/Trash/",5,true,true);
        }

        if(bClean)
        {
            ui->stackedWidget->setCurrentIndex(0);
            ui->checkALL->setCheckState(Qt::Checked);

            ui->labTClean->setText("可清理的项目一共"+ByteconvStr(ByteTotal(lAppchache)+ByteTotal(lApplog)+ByteTotal(lCrash)+ByteTotal(lPkgCache)+ByteTotal(lTrash)));

        }
        ui->btnScan->show();
        ui->labscan->hide();

    }
    else
    {
        ui->btnScan->show();
        ui->labscan->hide();
        QMessageBox::information(this,"小心","您没有选择任何可清理的项目,请仔细检查");

    }
}

void Widget::on_checkAppCache_stateChanged(int arg1)
{
//    if(bcheck)
//        bcheck=true;
    changecheck();
}

void Widget::on_checkAppLog_stateChanged(int arg1)
{
//    if(bcheck)
//        bcheck=true;
    changecheck();
}

void Widget::on_checkCrashReports_stateChanged(int arg1)
{
//    if(bcheck)
//        bcheck=true;
    changecheck();
}

void Widget::on_checkPackageCache_stateChanged(int arg1)
{
//    if(bcheck)
//        bcheck=true;
    changecheck();
}

void Widget::on_checkTrash_stateChanged(int arg1)
{
//    if(bcheck)
//        bcheck=true;
    changecheck();
}

void Widget::on_checkSelectAllSystemScan_clicked()
{
    bcheck = true;
    if(ui->checkSelectAllSystemScan->checkState()==Qt::Checked)
    {
        ui->checkAppCache->setCheckState(Qt::Checked);
        ui->checkAppLog->setCheckState(Qt::Checked);
        ui->checkCrashReports->setCheckState(Qt::Checked);
        ui->checkPackageCache->setCheckState(Qt::Checked);
        ui->checkTrash->setCheckState(Qt::Checked);
        bcheck=false;
    }
    if(ui->checkSelectAllSystemScan->checkState()==Qt::Unchecked)
    {
        ui->checkAppCache->setCheckState(Qt::Unchecked);
        ui->checkAppLog->setCheckState(Qt::Unchecked);
        ui->checkCrashReports->setCheckState(Qt::Unchecked);
        ui->checkPackageCache->setCheckState(Qt::Unchecked);
        ui->checkTrash->setCheckState(Qt::Unchecked);
        bcheck=false;
    }
    if(ui->checkSelectAllSystemScan->checkState()==Qt::PartiallyChecked)
    {
        ui->checkSelectAllSystemScan->setCheckState(Qt::Checked);
        ui->checkAppCache->setCheckState(Qt::Checked);
        ui->checkAppLog->setCheckState(Qt::Checked);
        ui->checkCrashReports->setCheckState(Qt::Checked);
        ui->checkPackageCache->setCheckState(Qt::Checked);
        ui->checkTrash->setCheckState(Qt::Checked);
        bcheck=false;
    }
}
