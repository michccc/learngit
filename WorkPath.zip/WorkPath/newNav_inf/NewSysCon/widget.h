#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QThread>
#include <QObject>
#include "startitem.h"
#include <QTreeWidget>
#include <QtConcurrent>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

    int isH;
    int isW;
    void setTab(int index);

    bool bGif;

    int getService();       
    QStringList slCurrent;
    QStringList slCurrentL;
    struct stService
    {
        QString sSer;
        QString sDes;
        bool bEnable;
        bool bAct;
        void clear()
        {
            sSer = "";
            sDes = "";
            bEnable = false;
            bAct = false;
        }
    };
    QList <stService> serviceList;
    int ia;
    int ib;
    int iscount;
    void reserTab();

    int itimer;
    int getProcess(QString sFilter);
    int iCrec;
//    void reProTab();
    void killPro();
    QString recPID;
    QString sFilter;


    int getStartup();
    QList<startItem *> lStartUp;
    void saveStartup(QString sPath, QString sEXEc,QString sHide, QString sName);
    QStringList slSave;
    QString sPATH;
    QString sgUser;



//    void cleantree(QStringList slAPPlog,QStringList slAPPCache,QStringList slCrash,QStringList slPkg,QStringList slTrash);
    void computClean(QString sDir, int i, bool bChk, bool bScan);
    QString ByteconvStr(double llb);

    void updateParentItem(QTreeWidgetItem *item);
    static const quint64 KB = 1024;
    static const quint64 MB = 1048576;
    static const quint64 GB = 1073741824;
    static const quint64 TB = 1099511627776;
    bool bReTREE;
    long lTbyte;
    double ByteTotal(QList<long long> listL);
    quint64 dirFileSize(const QString &path);
    QStringList slAppcache;
    QList<long long> lAppchache;
    QStringList slApplog;
    QList<long long> lApplog;
    QStringList slCrash;
    QList<long long> lCrash;
    QStringList slPkgCache;
    QList<long long> lPkgCache;
    QStringList slTrash;
    QList<long long> lTrash;
    QList <QTreeWidgetItem*> ltClean;

    void ani();

    void changecheck();
    bool bcheck;


protected:
    void timerEvent(QTimerEvent *event);

public slots:
    void treeItemChanged(QTreeWidgetItem *item, int column);
//    void slotpro();


private slots:
    void datasacn();
    void on_comboBoot_currentIndexChanged(int index);


    void on_combRun_currentIndexChanged(int index);

//    void on_pushButton_clicked();

    void on_tablePro_cellClicked(int row, int column);

    void on_BtnKill_clicked();

    int onHeaderClicked(int);

    void on_pushButton_add_clicked();

    void on_btnScan_clicked();

    void on_checkSelectAllSystemScan_stateChanged(int arg1);

    void on_btnClean_clicked();


    void on_checkALL_clicked();

    void on_pushButton_clicked();

    void on_checkAppCache_stateChanged(int arg1);

    void on_checkAppLog_stateChanged(int arg1);

    void on_checkCrashReports_stateChanged(int arg1);

    void on_checkPackageCache_stateChanged(int arg1);

    void on_checkTrash_stateChanged(int arg1);

    void on_checkSelectAllSystemScan_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
