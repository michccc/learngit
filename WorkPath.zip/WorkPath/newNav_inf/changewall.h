#ifndef CHANGEWALL_H
#define CHANGEWALL_H

#include <QWidget>
#include <QCloseEvent>

namespace Ui {
class changeWall;
}

class changeWall : public QWidget
{
    Q_OBJECT

public:
    explicit changeWall(QWidget *parent = nullptr);
    ~changeWall();
    void changeWp(QString sDE,QString sCMD);
//    void closeEvent(QCloseEvent *event);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::changeWall *ui;
};

#endif // CHANGEWALL_H
