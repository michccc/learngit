#include "softman.h"
#include "ui_softman.h"
#include "dialog_repo.h"
#include <QFileInfo>
#include <QDir>
#include <QFile>
#include <QDebug>
#include <QRadioButton>
#include <QProcess>
#include <QMessageBox>
#include <QCheckBox>
#include <unistd.h>
#include <QMovie>

#define APT_SOURCES_LIST_D_PATH "/etc/apt/sources.list.d"
#define APT_SOURCES_LIST_PATH "/etc/apt/sources.list"

softMan::softMan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::softMan)
{
    ui->setupUi(this);
    ui->tabWidget->tabBar()->removeTab(2);
    ui->tabWidget->setCurrentIndex(0);
    ui->tableRepo->verticalHeader()->setVisible(false);
    ui->tableRepo->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableRepo->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableRepo->setShowGrid(false);
    ui->tableRepo->setFocusPolicy(Qt::NoFocus);
    ui->tableRepo->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    sFilter = ui->lineSreach->text();
    QFont font ( "Noto Sans CJK SC", 13, 63);
    ui->labelrepo->setFont(font);
    getRepo();

    ui->tableUninstall->verticalHeader()->setVisible(false);
    ui->tableUninstall->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableUninstall->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableUninstall->setShowGrid(false);
    ui->tableUninstall->setFocusPolicy(Qt::NoFocus);
    ui->tableUninstall->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    ui->tableUninstall->horizontalHeader()->setVisible(false);
    ui->labuninstallTitle->setFont(font);
    getPack();
    startTimer(900);

    QMovie *movie = new QMovie(":/PCman_RES/uninstall2.gif");
    movie->start();
    ui->labunani->setMovie(movie);
    ui->labunani->hide();
    bRebtn = false;

    ui->pushButton->hide();
}
void softMan::timerEvent(QTimerEvent *event)
{
    Q_UNUSED(event);
    QFile fUnsList("/home/iosoft");


    if(!fUnsList.exists())
    {
        ui->labunani->hide();
        ui->pushDel_2->setEnabled(true);
        if(bRebtn==true)
        {
            getPack();
            bRebtn=false;
        }

    }
    sFilter = ui->lineSreach->text();
    for(int r = 0 ; r < lRepo.count();r++)
    {
        if(!lRepo[r].sAddress.contains(sFilter,Qt::CaseInsensitive)&&sFilter!="")
        {
            ui->tableRepo->hideRow(r);
        }
        else
        {
            ui->tableRepo->showRow(r);
        }
    }
}

softMan::~softMan()
{
    delete ui;
}

int softMan::getPack()
{
//    int iP = -1;

//    ui->pushButton->setEnabled(false);
    QLabel *labelT = new QLabel;
    QPixmap pix(":/PCman_RES/package.png");  //图片路径
    labelT->setScaledContents(true);//设置图片适应label
//    layout->addWidget(labelT);
    labelT->setPixmap(pix);
//    tableT->setCellWidget(0,i,label1);//显示label

    ui->tableUninstall->clear();
    ui->tableUninstall->setRowCount(0);
    QProcess pPack;
    pPack.start("apt list --installed");
    pPack.waitForFinished();
    QString stPack = QString(pPack.readAllStandardOutput()).trimmed();
    QStringList slPack = stPack.split("\n");
    slPack.removeFirst();
    for(int ip = 0 ; ip < slPack.count() ; ip++)
    {
        ui->tableUninstall->insertRow(ip);
        QCheckBox *chb = new QCheckBox();
        chb->setFocusPolicy(Qt::NoFocus);
        chb->setCheckState(Qt::Unchecked);
        chb->setFixedWidth(20);
//        chb->setMaximumWidth(40);

        ui->tableUninstall->setCellWidget(ip,0,chb);
//        QLabel *tlg = new QLabel();
//        QLabel *labelT = new QLabel;
//        QPixmap pix(":/PCman_RES/package.png");  //图片路径
//        labelT->setFixedWidth(16);
//        labelT->setFixedHeight(16);
//        pix.scaled(16, 16, Qt::KeepAspectRatio, Qt::SmoothTransformation);
//        labelT->setScaledContents(true);//设置图片适应label
//        labelT->setPixmap(pix);
//        ui->tableUninstall->setCellWidget(ip,1,labelT);
//        ui->tableUninstall->setColumnWidth(1,3);
        ui->tableUninstall->hideColumn(1);
        QTableWidgetItem *stritem = new QTableWidgetItem(slPack[ip].split('/')[0]);
        stritem->setTextAlignment(Qt::AlignLeft);
        ui->tableUninstall->setItem(ip,2,stritem);
        if(ui->lineEdit->text().trimmed()!="")
        {
            if(!slPack[ip].split('/')[0].contains(ui->lineEdit->text(),Qt::CaseInsensitive))
            {
                ui->tableUninstall->hideRow(ip);
            }
            else
            {
                ui->tableUninstall->showRow(ip);
            }
        }
    }
    if (ui->tableUninstall->rowCount()<1)
    {
        ui->tableUninstall->setStyleSheet("#tableUninstall{background-image: url(:/PCman_RES/notice.jpg);}");
    }
    return  ui->tableUninstall->rowCount();
}

int softMan::getRepo()
{
    ui->pushEdit->setEnabled(false);
    ui->pushDel->setEnabled(false);
    int iRepo = 0;
//    ui->tableRepo->clearContents();
    for(int i = ui->tableRepo->rowCount();i>-1;i--)
    {
        ui->tableRepo->removeRow(i);
    }

    ui->tableRepo->setRowCount(0);
    lRepo.clear();
    QFileInfoList infList = QDir("/etc/apt/sources.list.d").entryInfoList({"*.list"}, QDir::Files, QDir::Time);
    infList.append(QFileInfo("/etc/apt/sources.list"));
    for(int f = 0 ; f < infList.count();f++)
    {
        QString sFile = infList[f].absoluteFilePath();
        QFile file(sFile);

        QString str;
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            while (!file.atEnd())
            {
                QByteArray line = file.readAll();
                str=QString(line);
            }
            file.close();
        }
//        qDebug()<<str;
        sturepo stupo;
        QStringList slrepo = str.trimmed().split('\n').filter(QRegExp("^\\s{0,}#{0,}\\s{0,}deb"));
        for(int l = 0 ; l < slrepo.count();l++)
        {
            stupo.clear();
            stupo.sAddress = slrepo[l];
            stupo.sPATH = infList[f].absoluteFilePath();
            lRepo.append(stupo);
        }
    }


    for(int iw = 0 ; iw < lRepo.count() ; iw++)
    {
        ui->tableRepo->insertRow(iw);
        QRadioButton *rb = new QRadioButton(lRepo[iw].sAddress,ui->tableRepo);
        rb->setFocusPolicy(Qt::NoFocus);
        rb->setFixedWidth(699);
        rb->setToolTip(lRepo[iw].sAddress);
        rb->setStyleSheet("color:#111111");
        ui->tableRepo->setCellWidget(iw,0,rb);
        QTableWidgetItem *witem = new QTableWidgetItem();
        if(lRepo[iw].sAddress.contains("#",Qt::CaseInsensitive))
        {
            witem->setCheckState(Qt::Unchecked);
        }
        else
        {
            witem->setCheckState(Qt::Checked);
        }

        ui->tableRepo->setItem(iw,1,witem);

        connect(rb, SIGNAL(clicked()), this, SLOT(OnBtnClicked()));
    }

//    ui->tableRepo->resizeRowsToContents();
//    ui->tableRepo->setColumnWidth(0,200);
    return iRepo;
}

void softMan::on_tableRepo_cellClicked(int row, int column)
{
    if(row <= lRepo.count())
    {
        if(ui->tableRepo->item(row,column)!=nullptr)
        {
            if(ui->tableRepo->item(row,column)->checkState()==Qt::Checked)
            {
                lRepo[row].sAddress.replace("#","");
            }
            else if(ui->tableRepo->item(row,column)->checkState()==Qt::Unchecked)
            {
                lRepo[row].sAddress.replace("#","");
                lRepo[row].sAddress.insert(0,"#");
            }
            ui->tableRepo->selectRow(row);
            reconRepo(lRepo[row].sAddress,row);
        }
    }

}
void softMan::OnBtnClicked()
{

    QRadioButton* rb;
    for(int i = 0 ; i < ui->tableRepo->rowCount();i++)
    {
        rb = (QRadioButton*)ui->tableRepo->cellWidget(i,0);
        if(rb->isChecked())
        {
            gC = i;
        }
    }
    if(gC!=-1)
    {
        ui->pushEdit->setEnabled(true);
        ui->pushDel->setEnabled(true);
    }
    if(gC==-1||gC==-2)
    {
        ui->pushEdit->setEnabled(false);
        ui->pushDel->setEnabled(false);
    }
//    qDebug()<<gC;
}

void softMan::on_pushEdit_clicked()
{
    Dialog_repo *frepo = new Dialog_repo(lRepo[gC].sAddress,gC,this);

    frepo->showNormal();
}

void softMan::reconRepo(QString sNewAddr ,int index)
{

    ui->pushEdit->setEnabled(false);
    ui->pushDel->setEnabled(false);
    QRegExp sep("\\s+");
    QProcess pUser;
    pUser.start("w");
    pUser.waitForFinished();
    QString sUser = QString(pUser.readAllStandardOutput().trimmed()).split('\n')[2].split(sep)[0].trimmed();

    sturepo strepo;
    if(index==-2&&sNewAddr!="")
    {
        strepo.sAddress = sNewAddr;
        strepo.sPATH="/etc/apt/sources.list";
        lRepo.append(strepo);
    }
    if(index > 0&&index < lRepo.count())
    {
        lRepo[index].sAddress = sNewAddr;
    }
    sUser="";
    QFile iob("/home/"+sUser+"boolrepo");
    iob.open(QIODevice::WriteOnly);
    iob.close();
    QFile iop("/home/"+sUser+"iorepo");
    iop.open(QIODevice::WriteOnly);
    iop.close();
    for(int il = 0 ; il < lRepo.count() ; il++)
    {
        if(iop.open(QIODevice::ReadWrite | QIODevice::Text))
        {
            QTextStream stream(&iop);
            stream.seek(iop.size());
            stream<<lRepo[il].sPATH<<"\n";
            stream<<lRepo[il].sAddress<<"\n";
            stream<<"<------>"<<"\n";
            iop.close();
        }
    }
    while(iob.exists())
    {

    }
    getRepo();

}

void softMan::on_pushAdd_clicked()
{
    Dialog_repo *frepo = new Dialog_repo("",-2,this);

    frepo->showNormal();
}

void softMan::on_pushDel_clicked()
{
    if(QMessageBox::information(this,"小心","您将要删除一个软件源,是否继续?",QMessageBox::Ok,QMessageBox::No)==QMessageBox::Ok)
    {
        lRepo.removeAt(gC);
        reconRepo("",-2);
    }

}

void softMan::on_pushDel_2_clicked()
{


    QStringList slRemove;
    for (int r = 0 ;r < ui->tableUninstall->rowCount();r++)
    {
        if(ui->tableUninstall->cellWidget(r,0)!=nullptr&&ui->tableUninstall->item(r,2)!=nullptr)
        {
            QCheckBox *cb = (QCheckBox*)ui->tableUninstall->cellWidget(r,0);
            if(cb->checkState()==Qt::Checked)
            {
                slRemove.append(ui->tableUninstall->item(r,2)->text());
            }
        }
    }
    if(slRemove.count()>0)
    {
        if(QMessageBox::Ok==QMessageBox::information(this,"注意","当您点击确定以后，您所选择的软件包将被卸载",QMessageBox::Ok,QMessageBox::Cancel))
        {
            QRegExp sep("\\s+");
            QProcess pUser;
            pUser.start("w");
            pUser.waitForFinished();
            QString sgUser = QString(pUser.readAllStandardOutput().trimmed()).split('\n')[2].split(sep)[0].trimmed();

            sgUser="";
            QFile fDelList("/home/"+sgUser+"/.celanList.txt");
            QFile fKillList("/home/"+sgUser+"/.KillList.txt");
            QFile fUnsList("/home/"+sgUser+"iosoft");
//            fDelList.open(QIODevice::WriteOnly);
//            fDelList.close();
//            fKillList.open(QIODevice::WriteOnly);
//            fKillList.close();
            fUnsList.open(QIODevice::WriteOnly);
            fUnsList.close();
            if(fUnsList.open(QIODevice::ReadWrite | QIODevice::Text))
            {
                QTextStream stream(&fUnsList);
                stream.seek(fUnsList.size());
                for(int i = 0 ; i < slRemove.count() ; i++)
                {
                    stream<<slRemove[i]<<'\n';
                }

                fUnsList.close();
            }

//            for(int i = 0 ; i < ui->tableUninstall->rowCount() ; i++)
//            {
//                for(int s = 0 ; s < slRemove.count() ; s++)
//                {
//                    if(ui->tableUninstall->cellWidget(i,0)!=nullptr&&ui->tableUninstall->item(i,2)!=nullptr)
//                    {
//                        if(ui->tableUninstall->item(i,2)->text()==slRemove[s])
//                        {
//                            ((QCheckBox*)ui->tableUninstall->cellWidget(i,0))->setEnabled(false);
//                        }
//                    }
//                }

//            }
//            ui->pushButton->setEnabled(true);
            bRebtn=true;
            ui->pushDel_2->setEnabled(false);
            ui->labunani->show();

    //        slRemove.insert(0, "remove");
    //        slRemove.insert(1, "-y");
    //        QProcess pRemove;
    //        pRemove.start("apt-get",slRemove);
    //        pRemove.waitForFinished();
    //        pRemove.close();
    //        getPack();
        }
    }




}



void softMan::setTab(int index)
{
    if(index<2&&index>-1)
    {
        ui->tabWidget->setCurrentIndex(index);
    }
}

void softMan::on_pushButton_clicked()
{
    QRegExp sep("\\s+");
    QProcess pUser;
    pUser.start("w");
    pUser.waitForFinished();
    QString sgUser = QString(pUser.readAllStandardOutput().trimmed()).split('\n')[2].split(sep)[0].trimmed();
    sgUser="";
    QFile fUnsList("/home/"+sgUser+"iosoft");
    fUnsList.open(QIODevice::WriteOnly);
    fUnsList.close();
    getPack();
}

void softMan::on_pushSearch_clicked()
{
    for(int i = 0 ; i < ui->tableUninstall->rowCount() ; i ++)
    {
        if(ui->tableUninstall->item(i,2)!=nullptr)
        {
            if(!ui->tableUninstall->item(i,2)->text().contains(ui->lineEdit->text(),Qt::CaseInsensitive))
            {
                ui->tableUninstall->hideRow(i);
            }
            else
            {
                ui->tableUninstall->showRow(i);
            }
        }
        if(ui->lineEdit->text().trimmed()=="")
        {
            ui->tableUninstall->showRow(i);
        }
    }
}

void softMan::on_lineEdit_returnPressed()
{
    for(int i = 0 ; i < ui->tableUninstall->rowCount() ; i ++)
    {
        if(ui->tableUninstall->item(i,2)!=nullptr)
        {
            if(!ui->tableUninstall->item(i,2)->text().contains(ui->lineEdit->text(),Qt::CaseInsensitive))
            {
                ui->tableUninstall->hideRow(i);
            }
            else
            {
                ui->tableUninstall->showRow(i);
            }
        }
        if(ui->lineEdit->text().trimmed()=="")
        {
            ui->tableUninstall->showRow(i);
        }
    }
}
