#include "dialog_repo.h"
#include "ui_dialog_repo.h"
#include <QMessageBox>

Dialog_repo::Dialog_repo(QString aAddress, int index, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_repo)
{
    ui->setupUi(this);
    parIndex = index;
    parStr = aAddress;
    ui->lineEdit->setText(aAddress);
    softW = (softMan*)parent;
    this->setWindowFlags(windowFlags()&~ Qt::WindowMinMaxButtonsHint);
    this->setWindowFlags(this->windowFlags()&~Qt::WindowMaximizeButtonHint&~Qt::WindowMinimizeButtonHint);
}

Dialog_repo::~Dialog_repo()
{
    delete ui;
}

void Dialog_repo::on_pushreboCan_clicked()
{
    this->close();
}

void Dialog_repo::on_pushrepook_clicked()
{
    if(ui->lineEdit->text()!=""&&ui->lineEdit->text().contains("deb",Qt::CaseInsensitive))
    {
        softW->reconRepo(ui->lineEdit->text(),parIndex);
        this->close();
    }
    else
    {
        QMessageBox::information(this,"小心","请仔细检查软件仓库地址的输入");
    }

}
