#include "startup.h"
#include "ui_startup.h"
#include <QScreen>
#include <QProcess>
#include <QTimer>
#include <QTime>
#include <QDebug>
#include "signal_interface.h"
//#include "/data/home/thtf/x86pkg/build-single_startup-Desktop_Qt_5_11_3_GCC_64bit-Release/signal_interface.h"


//#include "app.h"
//#include "Pages/StartupApps/startup_apps_page.h"
//#include "Pages/AptSourceManager/apt_source_manager_page.h"
//static App *APP;
startup::startup(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::startup)
{
    ui->setupUi(this);

    stup = new org::stup::Stup::Startup("org.stup.Stup","/stup",
                                        QDBusConnection::sessionBus(),this);

    ix = -50 ;
    iy = 150;
    QScreen *screen=QGuiApplication::primaryScreen ();
    QRect mm=screen->availableGeometry() ;
    screen_width = mm.width();
    screen_height = mm.height();
    this->setFixedSize(screen_width/5,screen_height/3);
    this->setWindowFlag(Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->move(screen_width-screen_width/5,screen_height-screen_height/3);

    startTimer(300);
    init();
}

void startup::timerEvent(QTimerEvent *event)
{
    Q_UNUSED(event);
    if (stup->isValid()==false)
        this->close();
//        ui.label->setText("connected");
//    else

//        ui.label->setText("disconnected");
}

void startup::getBootTime(QString scmd)
{
    QProcess p;
    QStringList slBtime;
    QStringList slSystime;
    QStringList slGUItime;
    QString sSystime;
    QString sGUItime;
    int iSystime = 0;
    int iGUItime = 0;
    p.start(scmd);
    p.waitForFinished();
    sBoottime = p.readAllStandardOutput();
    slBtime=sBoottime.split("\n");

    if(slBtime.count()>0)
    {
        if(slBtime[0].contains('=',Qt::CaseInsensitive))
        {
            slSystime=slBtime[0].split("=");
            sSystime=slSystime[slSystime.count()-1].split("s")[0];
        }
    }
    if(slBtime.count()>1)
    {
        if(slBtime[1].contains("in userspace",Qt::CaseInsensitive))
        {
            slGUItime=slBtime[1].split(" ");
            sGUItime=slGUItime[3].split("s")[0];
        }
    }

    iSystime = sSystime.toFloat();
    iGUItime = sGUItime.toFloat();
    qDebug()<<sSystime<<sGUItime<<iSystime<<iGUItime;
    if((iSystime+iGUItime)<=60)
    {
        sBoottime = QString::number(iSystime+iGUItime);
        ui->labTime->setText(sBoottime);
        ui->labMin->hide();
        ui->labTimeMin->hide();
    }
    else
    {
        int imin = 0;
        int isec = 0;
        isec = (iSystime+iGUItime)%60;
        imin = (iSystime+iGUItime)/60;
        ui->labMin->setText("\n分");
        ui->labTimeMin->setText(QString::number(imin));
        ui->labTime->setText(QString::number(isec));
    }



}
void startup::init()
{

//    APP = (App*)wapp;
    QPalette pa;
    pa.setColor(QPalette::WindowText,Qt::white);
    ui->widget->hide();
    ui->labSec->setPalette(pa);
    ui->labTime->setPalette(pa);
    ui->labTimetitle->setPalette(pa);

    ui->labMin->setPalette(pa);
    ui->labTimeMin->setPalette(pa);

    QPalette pal;
    pal.setColor(QPalette::WindowText,QColor(20,43,120));
    ui->label->setPalette(pal);


    QFont font;
    font.pointSize();
    ui->label->setFont(font);

    ui->labSec->setAttribute(Qt::WA_TranslucentBackground);
    ui->labTime->setAttribute(Qt::WA_TranslucentBackground);
    ui->labMin->setAttribute(Qt::WA_TranslucentBackground);
    ui->labTimeMin->setAttribute(Qt::WA_TranslucentBackground);
    ui->labTimetitle->setAttribute(Qt::WA_TranslucentBackground);

    ui->pushButton->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButton->setFlat(true);
    ui->pushButton->setStyleSheet("QPushButton{border:none;background:transparent;}");
//    ui->pushButton->setIconSize(QSize(24,24));
//    ui->pushButton->setFixedSize(28,28);
    ui->pushButton->setFocusPolicy(Qt::NoFocus);

    ui->pushButton_2->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButton_2->setFlat(true);
    ui->pushButton_2->setStyleSheet("QPushButton{border:none;background:transparent;}");
    ui->pushButton_2->setFocusPolicy(Qt::NoFocus);

    ui->pushButton_3->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButton_3->setFlat(true);
    ui->pushButton_3->setStyleSheet("QPushButton{border:none;background:transparent;}");
    ui->pushButton_3->setFocusPolicy(Qt::NoFocus);

    ui->pushButton_4->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButton_4->setFlat(true);
    ui->pushButton_4->setStyleSheet("QPushButton{border:none;background:transparent;}");
    ui->pushButton_4->setFocusPolicy(Qt::NoFocus);

    ui->pushButton_5->setAttribute(Qt::WA_TranslucentBackground);
    ui->pushButton_5->setFlat(true);
    ui->pushButton_5->setStyleSheet("QPushButton{border:none;background:transparent;}");
    ui->pushButton_5->setFocusPolicy(Qt::NoFocus);

    ui->verticalLayout_2->setSpacing(0);
    ui->verticalLayout_2->setMargin(0);
    ui->horizontalLayout_3->setSpacing(0);
    ui->horizontalLayout_3->setMargin(0);
    ui->horizontalLayout_2->setSpacing(0);
    ui->horizontalLayout_2->setMargin(0);
//    ui->horizontalLayout->setSpacing(0);
//    ui->horizontalLayout->setMargin(0);

    ui->verticalLayout->setSpacing(0);
    ui->verticalLayout->setMargin(0);

    getBootTime("systemd-analyze");

    repoint();



}
void startup::repoint()
{

//    ui->widget->move(screen_height/3,screen_height/5);
    ui->widget->show();

//    for(int i  = screen_height/4 ; i >0 ; i--)
//    {
//        ui->widget->move(0,i);
//        msleep(3);
//    }
}
void startup::msleep(unsigned int msec)
{
    QTime stoptime = QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<stoptime)
    {
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
    }
}
startup::~startup()
{
    delete ui;
}

void startup::on_pushButton_clicked()
{
//    for(int i  = 0 ; i <screen_height/4 ; i++)
//    {
//        ui->widget->move(0,i);
//        msleep(1);
//    }
//    stup->closewindow();
    qDebug()<<"close";
    this->close();
//    stup->closewindow();
}

void startup::on_pushButton_2_clicked()
{
//    APP->showNormal();
//    APP->bootclean(2);
    stup->clean();
    qDebug()<<"speedup";
}

void startup::on_pushButton_3_clicked()
{
    stup->boot();
    qDebug()<<"bootspeed";
//    APP->showNormal();
//    APP->bootclean(1);
}

void startup::on_pushButton_5_clicked()
{
    stup->uninstall();
    qDebug()<<"uninstall";
//    APP->showNormal();
//    APP->bootclean(3);
}

void startup::on_pushButton_4_clicked()
{
    stup->clean();
    qDebug()<<"speedup";
//    printf("speedup");
//    APP->showNormal();,.
//    APP->bootclean(2);
}
