#include "startup.h"
#include <QMutex>
#include <QProcess>
#include <QDebug>

StartUp::StartUp()
{
    isStop = false;
}

void StartUp::closeThread()
{
    isStop = true;
}

void StartUp::run()
{
    printf("Starting...\n");
    QProcess proRunL;
    QProcess proStart;
    QString sRUN;
    proRunL.start("runlevel");
    proRunL.waitForFinished();
    sRUN = proRunL.readAllStandardOutput();
    sleep(1);
    qDebug()<<"thread1";
    if(sRUN.contains('5',Qt::CaseSensitive))
    {
        proStart.startDetached("newNav_inf");
        proStart.startDetached("single_startup");
        proStart.close();
        proRunL.close();
        isStop = true;
        this->quit();
        qDebug()<<"thread1 exit";
    }





}
