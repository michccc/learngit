#ifndef GETSYSINF_H
#define GETSYSINF_H
#include<QThread>

class GetSysInf : public QThread
{
public:
    GetSysInf();
    QStringList slGetGRAPHICS;
    QStringList slGetDISKs;
    QStringList slGetRAM;

    struct stRAM
    {
        QString sSize;
        QString sType;
        QString sSpeed;
    };
    QList<stRAM> lRAM;

    struct stGRAPHICS
    {
        QString sGPU;
        QString sVRAM;
        QString sBit;
    };
    QList<stGRAPHICS> lGRAPHICS;

    struct stDISK
    {
        QString sRemove;
        QString sSize;
        QString sModel;
        QString sDev;
        QString sUsed;
        QString sPar;
        int     iRemove;
        void clear()
        {
            sRemove = "";
            sSize = "";
            sModel = "";
            sDev = "";
            sUsed = "";
            sPar = "";
            iRemove = 0;
        }
    };
    QList<stDISK> lDISKs;


protected:
    virtual void run();

private:
    volatile bool isStop;
};

#endif // GETSYSINF_H
