#ifndef NEW_NAVINF_H
#define NEW_NAVINF_H

#include <QWidget>
#include <QSystemTrayIcon>
#include <QMenu>
#include "SystemInf/systeminf.h"
#include "NewDash/newdash.h"
#include "NewSysCon/widget.h"
#include "NewSoftMan/softman.h"
//#include "NewDash/floatpan.h"
#include "signal_interface.h"
#include "changewall.h"
#include "help_about.h"
namespace Ui {
class New_NavInf;
}

class New_NavInf : public QWidget
{
    Q_OBJECT

public:
    explicit New_NavInf(QWidget *parent = nullptr);
    ~New_NavInf();
    org::stup::Stup::Startup *stup;

    bool binfHover = true;
    bool bdashHover = true;
    bool bsysConHover = true;
    bool bsoftHover = true;
    bool bResHover = true;
    bool bhelpHover = true;
    bool b360Hover = true;

    changeWall *cw;
    help_about *ha;

    systeminf *sysinf;
    Widget *syscon;
    NewDash *dashboard;
    softMan *soft;

    QSystemTrayIcon *mSysTrayIcon;
    QMenu *mMenu;
    QAction *mStartUp;
    QAction *mExit;
    QAction *mChangeWall;

    //floatpan *f;
    QList <QWidget*> lWpage;
    void selectPage(int index);
    void confirmQuit();

    void syncStartUp();

    QPoint offset;
    void mousePressEvent(QMouseEvent * event)override;
    void mouseMoveEvent(QMouseEvent * event)override;
    void mouseReleaseEvent(QMouseEvent * event)override;
    bool isPressedWindow;
private:
    Ui::New_NavInf *ui;
protected:
    bool eventFilter(QObject *obj, QEvent *event) override;  //事件过滤

public Q_SLOTS:
    void clean();
    void boot();
    void uninstall();
    void closewindow();

Q_SIGNALS:
    void crashed();

private slots:
    void on_butinf_clicked();
    void on_butdash_clicked();
    void on_butsys_clicked();
    void on_butsoft_clicked();
    void on_butres_clicked();
    void on_but360_clicked();

    void on_setStartUp();
    void on_changeWall();
    void on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason);
    void on_exitApp();
    void on_toolquit_triggered(QAction *arg1);
    void on_toolquit_clicked();
    void on_toolmin_clicked();
    void on_toolhelp_triggered(QAction *arg1);
    void on_toolhelp_clicked();
    void on_toolButton_clicked();
};

#endif // NEW_NAVINF_H
