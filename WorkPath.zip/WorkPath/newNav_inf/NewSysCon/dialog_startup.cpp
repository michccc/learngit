#include "dialog_startup.h"
#include "ui_dialog_startup.h"
#include <QFile>
#include <QMessageBox>
#include "widget.h"

Dialog_startup::Dialog_startup(QString sFile,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_startup)
{
    ui->setupUi(this);
    w = parent;
    sfileP = sFile.trimmed();
    bE=true;
    if(sFile.trimmed().right(7)!="desktop")
    {
        bE=false;
        savePath = sfileP;
    }
    sCon = "Unkonwn";
    QFile file(sFile);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            QByteArray line = file.readAll();
            QString str(line);
            sCon = str;
        }
        file.close();
    }

    QStringList slDesk;

    slDesk = sCon.split('\n');
    for(int s = 0 ; s< slDesk.count();s++)
    {
        if(slDesk[s].contains("Name=",Qt::CaseInsensitive)/*&&slDesk[s].contains("=",Qt::CaseInsensitive)*/)
        {
            ui->lineEdit->setText(slDesk[s].split('=')[1]);
            sCAN0 = slDesk[s].split('=')[1];
        }
        if(slDesk[s].contains("Exec",Qt::CaseInsensitive)&&slDesk[s].contains("=",Qt::CaseInsensitive))
        {
            ui->lineEdit_2->setText(slDesk[s].split('=')[1]);
            sCAN1 = slDesk[s].split('=')[1];
        }
    }

}

Dialog_startup::~Dialog_startup()
{
    delete ui;
}

void Dialog_startup::on_pushButton_can_clicked()
{
    ui->lineEdit->setText(sCAN0);
    ui->lineEdit_2->setText(sCAN1);
    this->close();
}

void Dialog_startup::on_pushButton_ok_clicked()
{
    Widget *wPar = (Widget*)w;

    if(ui->lineEdit->text()==""||ui->lineEdit_2->text()=="")
    {
        QMessageBox::information(this,"小心","有项目没有填写完整，请仔细检查");
    }
    else
    {
        if(QMessageBox::information(this,"小心","保存更改并退出？")==QMessageBox::Ok)
        {
            QFile fe(ui->lineEdit_2->text().split(" ")[0]);
            QFile file("/usr/bin/"+ui->lineEdit_2->text().split(" ")[0]);
            if(fe.exists()||file.exists())
            {
                if(!bE)
                {
                    wPar->saveStartup(savePath+ui->lineEdit->text()+".desktop","Exec="+ui->lineEdit_2->text(),
                                      "Hidden=false","Name="+ui->lineEdit->text());
                }
                else
                {
                    wPar->saveStartup(sfileP,"Exec="+ui->lineEdit_2->text(),
                                      "Hidden=false","Name="+ui->lineEdit->text());
                }
                wPar->getStartup();
                this->close();
            }
            else
            {
                QMessageBox::information(this,"小心","您指定的启动命令似乎不指向一个合法的文件,请仔细检查");
            }

        }
    }




}
