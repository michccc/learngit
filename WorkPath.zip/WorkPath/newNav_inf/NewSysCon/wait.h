#ifndef WAIT_H
#define WAIT_H

#include <QObject>
#include <QThread>

class wait : public QObject
{
    Q_OBJECT
public:
    explicit wait(QObject *parent = nullptr);

signals:

public slots:
};

#endif // WAIT_H
