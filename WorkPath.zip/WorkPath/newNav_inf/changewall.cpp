#include "changewall.h"
#include "ui_changewall.h"
#include <QProcess>
#include <QDir>

changeWall::changeWall(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::changeWall)
{
    ui->setupUi(this);



}

changeWall::~changeWall()
{
    delete ui;
}

void changeWall::on_pushButton_clicked()
{
    QImage *image = new  QImage;
    image->load(":/PCman_RES/1b.png");

    image->save(QDir::homePath()+"/wp.jpg");
    QString sPATH = QDir::homePath()+"/wp.jpg"/*+ QString("'")*/;
    changeWp("sDEout",sPATH);
}

void changeWall::changeWp(QString sDE,QString sCMD)
{
    QProcess p;
    QString btnCMD;
    QString sDeepin = QString("gsettings set com.deepin.wrap.gnome.desktop.background picture-uri ");
    int isys = 1;
//    if(sSYSout.contains("uos",Qt::CaseSensitive))
//        isys = 1;

    int ide = 1;
//    if(sDE=="deepin")
//        ide = 1;

    if(isys == 1 && ide ==1)//deepin and DDE
    {
        btnCMD = sDeepin+sCMD;
        p.start(btnCMD);
        p.waitForFinished(900);
        p.close();
    }
}

void changeWall::on_pushButton_2_clicked()
{
    QImage *image = new  QImage;
    image->load(":/PCman_RES/2b.png");

    image->save(QDir::homePath()+"/wp.jpg");
    QString sPATH = QDir::homePath()+"/wp.jpg"/*+ QString("'")*/;
    changeWp("sDEout",sPATH);
}

void changeWall::on_pushButton_3_clicked()
{
    QImage *image = new  QImage;
    image->load(":/PCman_RES/3b.png");

    image->save(QDir::homePath()+"/wp.jpg");
    QString sPATH = QDir::homePath()+"/wp.jpg"/*+ QString("'")*/;
    changeWp("sDEout",sPATH);
}

void changeWall::on_pushButton_4_clicked()
{
    QImage *image = new  QImage;
    image->load(":/PCman_RES/4b.png");

    image->save(QDir::homePath()+"/wp.jpg");
    QString sPATH = QDir::homePath()+"/wp.jpg"/*+ QString("'")*/;
    changeWp("sDEout",sPATH);
}
//void changeWall::closeEvent(QCloseEvent *event)
//{
//    Q_UNUSED(event);
//    this->hide();
//}
