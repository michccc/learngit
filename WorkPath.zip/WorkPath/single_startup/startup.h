#ifndef STARTUP_H
#define STARTUP_H

#include <QWidget>
#include "signal_interface.h"
//#include "/data/home/thtf/x86pkg/build-single_startup-Desktop_Qt_5_11_3_GCC_64bit-Release/signal_interface.h"

namespace Ui {
class startup;
}

class startup : public QWidget
{
    Q_OBJECT

public:
    explicit startup(QWidget *parent = nullptr);
    ~startup();
    int ix , iy;
    void msleep(unsigned int msec);
    void getBootTime(QString scmd);
    void repoint();
    int screen_width;
    int screen_height;
    QString sBoottime;
    void init();
    QWidget *wapp;
    QWidget *wsoft;
    QWidget *wboot;
//    QString

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();
protected:
    void timerEvent(QTimerEvent *event);
private:
    Ui::startup *ui;
    org::stup::Stup::Startup *stup;
};

#endif // STARTUP_H
