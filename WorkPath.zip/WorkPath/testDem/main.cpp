#include <QCoreApplication>
//#include "signal_adaptor.h"
//#include "dbuspar.h"

#include <sys/wait.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QProcess>


void init_daemon(void);//守护进程初始化函数
int main(int argc, char *argv[])
{
//    init_daemon();//初始化为Daemon
    QCoreApplication a(argc, argv);
    QFile f("/home/io");//kill process
    QFile fkill("/home/iok");//delete file
    QFile frepo("/home/iorepo");//repo file;
    QFile fsoft("/home/iosoft");//soft file;
    QFile iob("/home/boolrepo");
    QFile fhardinf("/home/refreshinf");
    
//    qputenv("DXCB_FAKE_PLATFORM_NAME_XCB", "true");
//    qputenv("HOME", "/root");
//    qputenv("SHELL", "/bin/bash");
//    QFile foe("/home/env.txt");
//    QString st = "blank";
//    st = QString(qgetenv("DXCB_FAKE_PLATFORM_NAME_XCB"));
//    st.append(QString(qgetenv("HOME")));
//    st.append(QString(qgetenv("SHELL")));
//    if(st == "")
//        st="blank";
//    QProcess prot;
//    prot.startDetached("/data/home/thtf/20200629/build-pcman_backservice-unknown-Release/pcman_backservice");

//    qDebug()<<st;
//    foe.open(QIODevice::WriteOnly | QIODevice::Text);
//    foe.close();
//    if(foe.open(QIODevice::ReadWrite | QIODevice::Text))
//    {
//        QTextStream stream(&foe);
//        stream.seek(foe.size());
//        stream<<st<<"\n";
//        foe.close();
//    }

    int i  = -100;

    while (true)
    {
        i  = -100;
        if(fhardinf.exists())
        {
            QProcess prot;
            prot.start("pcman_backservice");
            prot.waitForFinished();
            fhardinf.remove();
        }
        if(f.exists())
        {
            int ik = -1;
            if (f.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                while (!f.atEnd())
                {
                    QByteArray line = f.readLine();
                    QString str(line);
                    ik = str.trimmed().toInt();
                }
                f.close();
            }
            i = kill(ik,SIGKILL);
            f.remove();
        }

        if(fkill.exists())
        {
            QStringList slDel;
            if (fkill.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                while (!fkill.atEnd())
                {
                    QByteArray line = fkill.readAll();
                    QString str(line);
                    slDel = str.trimmed().split('\n');
                    fkill.close();
                }
                for(int id = 0 ; id < slDel.count() ; id++)
                {
                    QFile fd(slDel[id]);
                    QDir dd(slDel[id]);
                    if(fd.exists())
                        fd.remove();
                    if(dd.exists())
                        dd.removeRecursively();
                }

                fkill.remove();
            }
        }

        if(iob.exists())
        {
            QStringList ik ;
            if (frepo.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                while (!frepo.atEnd())
                {
                    QByteArray line = frepo.readAll();
                    QString str(line);
                    ik = str.trimmed().split("<------>\n");
//                    qDebug()<<ik;
                }
                frepo.close();

            }
            QStringList slE;
            for (int i = 0 ;i < ik.count();i++)
            {
                QStringList slrepo = ik[i].split('\n');
                if(slrepo.count()>1)
                {
                    QFile fRp(slrepo[0].trimmed().replace("\n",""));
                    bool be = true;

                    for (int e = 0 ;e < slE.count();e++)
                    {
                        if(slE.contains(slrepo[0],Qt::CaseInsensitive))
                        {
                            be=false;

                        }
                    }
                    slE<<slrepo[0];
                    if(be)
                    {
                        fRp.open(QIODevice::WriteOnly | QIODevice::Text);
                        fRp.close();
                    }
                    if(fRp.open(QIODevice::ReadWrite | QIODevice::Text))
                    {
                        QTextStream stream(&fRp);
                        stream.seek(fRp.size());
                        stream<<slrepo[1].trimmed()<<"\n";
                        fRp.close();
                    }
                }

            }
            frepo.remove();
            iob.remove();

        }

        if(fsoft.exists())
        {
            QStringList ik ;
            if (fsoft.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                while (!fsoft.atEnd())
                {
                    QByteArray line = fsoft.readAll();
                    QString str(line);
                    ik = str.trimmed().split("\n");
                }
                fsoft.close();
            }
//            QFile fDel("/usr/lib/systemd/system/startupdel.service");

            QFile fDel("/home/uninstallErr");
            fDel.open(QIODevice::WriteOnly);
            fDel.close();

//            QString sDs = "ExecStart=/usr/bin/dpkg -r";
            QProcess proATP;
            for (int i = 0 ;i < ik.count();i++)
            {
//                sDs = sDs + " "+ik[i];
                proATP.start("apt-get -y purge "+ik[i]);
                proATP.waitForFinished();
                QString sERR;
                sERR = QString(proATP.readAllStandardError());
                if(sERR!="")
                {
                    if (fDel.open(QIODevice::ReadWrite | QIODevice::Text))
                    {
                        QTextStream str(&fDel);
                        {
                            str<<sERR<<"\n"<<"******************";
                        }
                        fDel.close();
                    }
                }
            }


//            QString s0 = QString("[Unit]\n")+"Description=delsoft\n"+"Requires=sound.target\n"
//                    +"After=pcman.service\n"+"\n"+"[Service]\n"+"Type=simple\n"+sDs+"\n"
//                    +"[Install]\n"+"WantedBy=multi-user.target\n";
//            fDel.open(QIODevice::WriteOnly);
//            fDel.close();
//            if (fDel.open(QIODevice::ReadWrite | QIODevice::Text))
//            {
//                QTextStream str(&fDel);
//                {
//                    str<<s0;
//                }
//                fDel.close();
//            }
            fsoft.remove();

        }
        sleep(1);
    }

    return a.exec();
}
