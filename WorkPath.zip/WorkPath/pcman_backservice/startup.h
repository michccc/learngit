#ifndef STARTUP_H
#define STARTUP_H

#include<QThread>
class StartUp : public QThread
{
public:
    StartUp();
    void closeThread();
protected:
    virtual void run();

private:
    volatile bool isStop;
};

#endif // STARTUP_H
