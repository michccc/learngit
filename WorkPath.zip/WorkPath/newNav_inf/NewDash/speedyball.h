#ifndef SPEEDYBALL_H
#define SPEEDYBALL_H

#include <QWidget>
#include <QtCharts>
#include <QPieSlice>
#include <QEvent>
#include <QMouseEvent>
#include <unistd.h>
#include <QList>
#include "floatpan.h"

namespace Ui {
class speedyball;
}

class speedyball : public QWidget
{
    Q_OBJECT

public:
    explicit speedyball(QWidget *parent = nullptr);
    ~speedyball();
    void init();
    void SYBtime(qreal icpu,qreal imem0,qreal imem1);
    void SYBfloatup(QString up);
    void SYBfloatdown(QString down);
    void SYBfloatupunit(QString SYBupunit);
    void SYBfloatdownunit(QString SYBdownunit);
    void SYBfloatlineup(qreal rxtx,qreal down);
    void SYBfloatlinedown(qreal rxtx,qreal down);
    void SYBloadpic(qreal icpu);
    void mousePressEvent(QMouseEvent * event)override;
    void mouseMoveEvent(QMouseEvent * event)override;
    void mouseReleaseEvent(QMouseEvent * event)override;

    QPoint offset;
    bool isPressedWindow;
    bool bMove;
    bool smove=false;

    QPieSeries *seriseSYB = new QPieSeries();
    QPieSlice *sliceSYB = new QPieSlice();
    QPieSlice *sliceSYB1 = new QPieSlice();
    QChart *chartSYB = new QChart();
    QStringList SYBCPUcmd;
    floatpan *floatwidget;
    QList<int> sbufPos;
    int h = 0;
    int w = 0;

private:
    Ui::speedyball *ui;
protected:
    bool eventFilter(QObject *obj, QEvent *event) override;
};

#endif // SPEEDYBALL_H
