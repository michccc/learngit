#include <QCoreApplication>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QCryptographicHash>
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


    QFile fileNet("/home/netinf.txt");
    QFile fileSN("/home/diskinfSN.txt");
    QFile fileKey(QDir::homePath()+"/keys");

    QStringList slMAC;
    QString sHDDsn;
    QStringList slKey;

    if(fileNet.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!fileNet.atEnd())
        {
            QByteArray line = fileNet.readAll();
            QString str(line);
            slMAC = str.split('\n');
        }
    }
    fileNet.close();

    if(fileSN.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!fileSN.atEnd())
        {
            QByteArray line = fileSN.readAll();
            QString str(line);
            sHDDsn = str;
        }
    }
    fileSN.close();

//    qDebug()<<slMAC<<'\n'<<sHDDsn<<'\n';.

    QString sGenKEY;
    QByteArray bKey;
    for(int i = 0 ; i < slMAC.count() ; i++ )
    {
        if(slMAC[i]!="")
        {
            sGenKEY = slMAC[i]+sHDDsn;
            bKey.clear();
            bKey = QCryptographicHash::hash(sGenKEY.toLatin1(),QCryptographicHash::Sha3_512);
            slKey.append(QString(bKey.toHex()));
        }
    }
    qDebug()<<slKey<<'\n';

    fileKey.open(QIODevice::WriteOnly);
    fileKey.close();
    if(fileKey.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&fileKey);
        for(int ik = 0 ; ik < slKey.count() ; ik++)
        {
            stream << slKey[ik];
            stream << '\n';
        }

    }
    fileKey.close();

    if(argc>1)
    {
        if(QString(argv[1]) == "/gen")
        {
            if(fileKey.copy("/usr/thtfman.key"))
            {
                printf("Copy key file OK!\n");
            }
            else
            {
                printf("Copy key file Fail!\n");
            }
        }
    }

    return a.exec();
}
