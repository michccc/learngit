#include "dbuspar.h"
#include <QProcess>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
dbusPar::dbusPar(QObject *parent) : QObject(parent)
{

}

void dbusPar::clean()
{

}
void dbusPar::boot()
{

    int i = 0;
    i = system(" ");

    QString sk = "-1";
    QFile fk("/home/Test12.txt");
    if (fk.open(QIODevice::ReadWrite | QIODevice::Text))
    {

        QTextStream ts(&fk);
        ts<<i<<'\n';
        fk.close();
    }
//    pid_t childpid = iCmd;


}
void dbusPar::uninstall()
{

}
void dbusPar::closewindow()
{

}
