#include "speedyball.h"
#include "ui_speedyball.h"
#include <QScreen>

speedyball::speedyball(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::speedyball)
{
    ui->setupUi(this);
    floatwidget =new floatpan(nullptr,parent);
    SYBCPUcmd<<"-c"<<"top -b -n 1 | grep ' id'";



//    this->setWindowFlags();

    this->setWindowFlags(Qt::FramelessWindowHint | Qt::Tool | Qt::WindowStaysOnTopHint);
//    this->setWindowFlags();

    this->setAttribute(Qt::WA_TranslucentBackground);
    ui->widgetSYB->installEventFilter(this);

    ui->labelup->adjustSize();
    ui->labeldown->adjustSize();
    ui->labelupunit->adjustSize();
    ui->labeldownunit->adjustSize();
    ui->labelLOADSYB_2->adjustSize();
    this->setFixedHeight(126);
    this->setFixedWidth(126);
    QDesktopWidget* desktopWidget = QApplication::desktop();
    QRect screenRect = desktopWidget->screenGeometry();
    w = screenRect.width();
    h = screenRect.height();
    init();
}

speedyball::~speedyball()
{
    delete ui;
}
void speedyball::SYBtime(qreal icpu,qreal imem0,qreal imem1)
{
    //ui->labelLOADSYB_2->setText(QString::number(100-icpu,'f',1));
    sliceSYB->setValue(100-icpu);//占用
    sliceSYB1->setValue(icpu);
    floatwidget->fslCPU(icpu);
    floatwidget->fslMEM(imem0,imem1);

}
void speedyball::SYBfloatup(QString up)
{
    floatwidget->floatup(up);
    ui->labelup->setText(up);
}
void speedyball::SYBfloatdown(QString down)
{
    floatwidget->floatdown(down);
    ui->labeldown->setText(down);
}
void speedyball::SYBfloatupunit(QString SYBupunit)
{
    floatwidget->floatupunit(SYBupunit);
    ui->labelupunit->setText(SYBupunit);
}
void speedyball::SYBfloatdownunit(QString SYBdownunit)
{
    floatwidget->floatdownunit(SYBdownunit);
    ui->labeldownunit->setText(SYBdownunit);
}
void speedyball::SYBfloatlineup(qreal rxtx,qreal down)
{
    floatwidget->floatlineup(rxtx,down);
}
void speedyball::SYBfloatlinedown(qreal rxtx,qreal down)
{
    floatwidget->floatlinedown(rxtx,down);
}
void speedyball::SYBloadpic(qreal icpu)
{
    int x =(int )(100-icpu);
    int units = (x/1)%10;
    int tens = (x/10)%10;

    if(x>=80)//内存超标
    {
            ui->widgetSYB->setStyleSheet("#widgetSYB{background:url(:/PCman_RES/ball-bg-red.png);}");
            sliceSYB->setColor(QColor(0xe0,0x20,0x20));
            ui->labelLOADSYB_2->setFixedSize(20,36);
            switch (units)
            {
            case 0:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_0.png);");
                break;
            case 1:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_1.png);");
                break;
            case 2:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_2.png);");
                break;
            case 3:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_3.png);");
                break;
            case 4:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_4.png);");
                break;
            case 5:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_5.png);");
                break;
            case 6:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_6.png);");
                break;
            case 7:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_7.png);");
                break;
            case 8:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_8.png);");
                break;
            case 9:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_red_9.png);");
                break;
            default:
                   break;
            }
            switch (tens)
            {
            case 0:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_0.png);");
                break;
            case 1:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_1.png);");
                break;
            case 2:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_2.png);");
                break;
            case 3:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_3.png);");
                break;
            case 4:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_4.png);");
                break;
            case 5:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_5.png);");
                break;
            case 6:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_6.png);");
                break;
            case 7:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_7.png);");
                break;
            case 8:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_8.png);");
                break;
            case 9:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_red_9.png);");
                break;
            default:
                   break;
            }        
    }
    else //内存没超
    {
        ui->widgetSYB->setStyleSheet("#widgetSYB{background:url(:/PCman_RES/ball-bg-blue.png);}");
        sliceSYB->setColor(QColor(0x4b,0x85,0xfa));
        if(x<10)
        {
            ui->labelLOADSYB_2->setFixedSize(8,36);
//            ui->labelLOADSYB_2->hide();
//            ui->labelLOADSYB_2->clear();
            switch (units)
            {
            case 0:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_0.png);");
                break;
            case 1:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_1.png);");
                break;
            case 2:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_2.png);");
                break;
            case 3:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_3.png);");
                break;
            case 4:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_4.png);");
                break;
            case 5:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_5.png);");
                break;
            case 6:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_6.png);");
                break;
            case 7:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_7.png);");
                break;
            case 8:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_8.png);");
                break;
            case 9:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_9.png);");
                break;
            default:
                   break;
            }
            ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/empty.png);");
        }
        else if(x>=10&&x<80)
        {
//            ui->labelLOADSYB_2->show();
            ui->labelLOADSYB_2->setFixedSize(20,36);
            switch (units)
            {
            case 0:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_0.png);");
                break;
            case 1:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_1.png);");
                break;
            case 2:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_2.png);");
                break;
            case 3:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_3.png);");
                break;
            case 4:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_4.png);");
                break;
            case 5:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_5.png);");
                break;
            case 6:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_6.png);");
                break;
            case 7:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_7.png);");
                break;
            case 8:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_8.png);");
                break;
            case 9:
                ui->label->setStyleSheet("background:url(:/PCman_RES/number_blue_9.png);");
                break;
            default:
                   break;
            }
            switch (tens)
            {
            case 0:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_0.png);");
                break;
            case 1:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_1.png);");
                break;
            case 2:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_2.png);");
                break;
            case 3:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_3.png);");
                break;
            case 4:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_4.png);");
                break;
            case 5:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_5.png);");
                break;
            case 6:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_6.png);");
                break;
            case 7:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_7.png);");
                break;
            case 8:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_8.png);");
                break;
            case 9:
                ui->labelLOADSYB_2->setStyleSheet("background:url(:/PCman_RES/number_blue_9.png);");
                break;
            default:
                   break;
            }
        }
    }



}
void speedyball::init()
{
    seriseSYB->setHoleSize(0.86);
    seriseSYB->setPieSize(0.96);
    seriseSYB->setPieStartAngle(0);
    seriseSYB->setPieEndAngle(360);
    sliceSYB->setValue(40);
    sliceSYB1->setValue(60);

    //sliceSYB->setColor(QColor(61, 204, 123));//绿色 SYB已占用,SYB1未占用
    sliceSYB1->setColor(QColor(255,255,255,0));
    sliceSYB->setColor(QColor(0x4b,0x85,0xfa));//已占用
    sliceSYB->setBorderColor(QColor(0,0,0,0));
    sliceSYB1->setBorderColor(QColor(0,0,0,0));
    seriseSYB->append(sliceSYB);
    seriseSYB->append(sliceSYB1);
    chartSYB->legend()->hide();
    chartSYB->addSeries(seriseSYB);
    chartSYB->createDefaultAxes();
    chartSYB->createDefaultAxes();
    chartSYB->setAnimationOptions(QChart::AnimationOption::GridAxisAnimations);
//    chartSYB->setAnimationOptions(QChart::AnimationOption::SeriesAnimations);
    chartSYB->setBackgroundVisible(false);
//    chartSYB->resize(180,180);
//    QSizeF s =chartSYB->size();
//    s;
//    chartSYB->zoomIn();
    chartSYB->setMargins(QMargins(0, 0, 0, 0));//设置外边界全部为0
    chartSYB->layout()->setContentsMargins(0, 0, 0, 0);//设置内边界全部为0，让饼图铺满chart
//    chartSYB->setContentsMargins(0,0,0,0);
    ui->widgetSYB->setRenderHint(QPainter::Antialiasing);//抗锯齿
    ui->widgetSYB->setChart(chartSYB);

}

void speedyball::mousePressEvent(QMouseEvent *event)
{
//    qDebug()<<event->button();
    if(event->button()==Qt::LeftButton)
    {
        isPressedWindow = true;
        offset = event->globalPos() - pos();

    }
}
void speedyball::mouseMoveEvent(QMouseEvent *event)
{

//    qDebug()<<event->button();
    if(event->buttons()&Qt::LeftButton&&isPressedWindow)
    {
        bMove = true;

        QPoint temp;
        temp = event->globalPos() - offset;
        move(temp);

    }
}

void speedyball::mouseReleaseEvent(QMouseEvent *event)
{
//    qDebug()<<event->button();

    isPressedWindow=false;
    if(bMove==false)
    {
        if(h-this->y()<400||w-this->x()<280)//加速球在这些位置上弹窗,窗体在关闭,加速球回不到原来的位置
        {
            sbufPos.append(this->x());//将当前加速球的位置保存
            sbufPos.append(this->y());
            smove = true;
            floatwidget->move(this->x(),this->y());
            floatwidget->show();
        }
        else//加速球不在上述位置上,正常显示
        {
            floatwidget->move(this->x(),this->y());
            floatwidget->show();
            smove = false;
        }
        this->hide();
    }
    bMove=false;
}


bool speedyball::eventFilter(QObject *obj, QEvent *event)
{
     switch (event->type())
     {
     case QEvent::MouseButtonPress:
//            if(obj==ui->widgetSYB&&bMove==false)
//            {
//                floatwidget->show();
//                floatwidget->move(this->x(),this->y());
//                this->hide();
//            }
            break;
//    case QEvent::MouseMove:
//            if(obj==ui->widgetSYB)
//            {

//                   floatwidget->show();
//                   floatwidget->move(this->x()-50,this->y()+150);


//            }
     default:
            break;
    }

    return QWidget::eventFilter(obj, event);
}
