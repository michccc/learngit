#include "startitem.h"
#include "ui_startitem.h"
#include <QFile>
#include <QDebug>
#include "widget.h"
#include "dialog_startup.h"
#include <QMessageBox>

static Widget *par;


static bool bgRe =false;
startItem::startItem(bool bRe, QString sFile, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::startItem)
{
    par= (Widget *)parent;
    strFILE = sFile;
    dia = new Dialog_startup(sFile,parent);
    ui->setupUi(this);
    sCon = "Unkonwn";
    QFile file(sFile);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            QByteArray line = file.readAll();
            QString str(line);
            sCon = str;
        }
        file.close();
    }
    bgRe = bRe;



    bool bN = true;
    slDesk = sCon.split('\n');
    for(int s = 0 ; s< slDesk.count();s++)
    {
        if(slDesk[s].contains("Name",Qt::CaseInsensitive)&&slDesk[s].contains("=",Qt::CaseInsensitive)&&bN==true)
        {
            ui->labname->setText(slDesk[s].split('=')[1]);
            bN=false;
        }
        if(slDesk[s].contains("Hidden=false",Qt::CaseInsensitive))
        {
            ui->chkIO->setCheckState(Qt::Checked);
        }
    }
//    qDebug()<<slDesk;
}

startItem::~startItem()
{
    delete ui;
}

void startItem::on_btnMod_clicked()
{
//    Dialog_startup *dia = new Dialog_startup(strFILE,par);
//    Dialog_startup *dia = new Dialog_startup(strFILE,this);
    par->getStartup();
    dia->show();
}

void startItem::on_btnDel_clicked()
{
    if(QMessageBox::information(par,"小心","你将要删除一个启动项目",QMessageBox::Ok,QMessageBox::Cancel)==QMessageBox::Ok)
    {
        QFile file(strFILE);
        if (file.exists())
        {
            file.remove();
        }
        par->getStartup();
    }

}

void startItem::on_chkIO_stateChanged(int arg1)
{
    int in =-1;
    int ie =-1;
    int ih =-1;
    bool bN = true;
    if(ui->chkIO->checkState()==Qt::Checked)
    {
        for(int s = 0 ; s< slDesk.count();s++)
        {
            if(slDesk[s].contains("Name=",Qt::CaseInsensitive)&&bN==true)
            {
                in = s;
                bN=false;
            }

            if(slDesk[s].contains("Exec=",Qt::CaseInsensitive))
                ie = s;
            if(slDesk[s].contains("Hidden=",Qt::CaseInsensitive))
            {
                slDesk[s]="Hidden=false";
                ih =s;
            }
        }
    }
    if(ui->chkIO->checkState()==Qt::Unchecked)
    {
        for(int s = 0 ; s< slDesk.count();s++)
        {
            if(slDesk[s].contains("Name=",Qt::CaseInsensitive))
            {
                in = s;
                bN=false;
            }
            if(slDesk[s].contains("Exec=",Qt::CaseInsensitive))
                ie = s;
            if(slDesk[s].contains("Hidden=",Qt::CaseInsensitive))
            {
                slDesk[s]="Hidden=true";
                ih =s;
            }
        }
    }
    qDebug()<<ie<<in<<ih<<bgRe;
    if(ie!=-1&&in!=-1&&ih!=-1&&bgRe)
    {
        par->saveStartup(strFILE,slDesk[ie],slDesk[ih],slDesk[in]);
//        qDebug()<<strFILE;
//        par->getStartup();
    }

}
