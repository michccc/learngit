#include "ftpmassdown.h"
#include "ui_ftpmassdown.h"
#include <QtNetwork>



FTPMassDown::FTPMassDown(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FTPMassDown)
{
    ui->setupUi(this);
    pUDPc = new QUdpSocket(this);
    pUDPc->bind(9999,QUdpSocket::ShareAddress);
    if(islanwan())
    {
        getudpiport();
    }
    else
    {
        getwaniport();
    }
}

FTPMassDown::~FTPMassDown()
{
    delete ui;
}

void FTPMassDown::on_pushButton_clicked()
{

    if(islanwan())
    {
        QString ip;
        ip.append(QString::number(strUDP.ip0)+'.'+QString::number(strUDP.ip1)+'.'+QString::number(strUDP.ip2)
              +'.'+QString::number(strUDP.ip3));
        ftpDown(ip,strUDP.uninport.iprot,"Downlist","/list.txt");
    }
    else
    {
//        qDebug()<<strwan.ip;
//        qDebug()<<strwan.port;
        ftpDown(strwan.ip,strwan.port,"Downlist","/list.txt");
    }
}

void FTPMassDown::ftpDown(QString sADDR,int iPORT,QString sLFname ,QString sRFname)
{
    QUrl url;
    QNetworkAccessManager manager;
    url.setScheme("ftp");
//    url.setUserName("root");
//    url.setPassword("1234");
    url.setHost(sADDR);
    url.setPort(iPORT);
    url.setPath(sRFname);
    QNetworkRequest request(url);
    QNetworkReply* reply = manager.get(request);

    QEventLoop eventLoop;
    QObject::connect(reply, SIGNAL(finished()), &eventLoop, SLOT(quit()));
    eventLoop.exec();
    if (reply->error() == QNetworkReply::NoError)
    {
        QFile file(sLFname);
        file.open(QIODevice::WriteOnly);
        file.write(reply->readAll());
        file.close();
    }
    else
    {
        QMessageBox::information(this,"ERROR",reply->errorString());
    }
}

void FTPMassDown::on_butGetPack_clicked()
{
    QString sFl;
    QStringList sslfl;
    QFile fL("Downlist");
    if(fL.open(QIODevice::ReadWrite|QIODevice::Text))
    {
        while (!fL.atEnd())
        {
            QByteArray line = fL.readAll();
            QString str(line);
            sFl = str;
        }
        fL.close();
    }
    sslfl = sFl.split('\n');
    for (int i = 0 ; i < sslfl.count();i++)
    {
        QStringList slSingel = sslfl[i].split("#*#");
        if(slSingel.count()>2)
        {
//            QString sLocalFileName;
            int nr = -1;
            for(int j = slSingel[0].length();j > 0 ; j--)
            {
                if(slSingel[0][j]=='/')
                {
                    nr = j;
                    break;
                }
            }
            if(islanwan()&&aptlist(slSingel[0].right(slSingel[0].length()-nr-1),slSingel[2]))//如果能连接到服务器并且本地不存在同名同版安装包
            {
                if(slSingel[1] == cpubuild())//如果当前文件的架构符合cpu的架构
                {
                    QString ip;
                    ip.append(QString::number(strUDP.ip0)+'.'+QString::number(strUDP.ip1)+'.'+QString::number(strUDP.ip2)
                          +'.'+QString::number(strUDP.ip3));
                    ftpDown(ip,strUDP.uninport.iprot,slSingel[0].right(slSingel[0].length()-nr-1),slSingel[0]);//下载文件
                    aptget(slSingel[0].right(slSingel[0].length()-nr-1));//安装文件
                }
            }
            else
            {
                ftpDown(strwan.ip,strwan.port,slSingel[0].right(slSingel[0].length()-nr-1),slSingel[0]);
            }
        }
    }

}

void FTPMassDown::getudpiport()
{
    //获取端口号和ip地址,UDP协议传来的主机号和ip地址
    connect(pUDPc,&QUdpSocket::readyRead,this,[=](){
            while (pUDPc->hasPendingDatagrams())
            {
                QByteArray datagram;
                datagram.resize(pUDPc->pendingDatagramSize());
                pUDPc->readDatagram(datagram.data(),datagram.size());
                strUDP.ip0 = datagram[4];
                strUDP.ip1 = datagram[5];
                strUDP.ip2 = datagram[6];
                strUDP.ip3 = datagram[7];
                strUDP.uninport.cprot[0] = datagram[8];
                strUDP.uninport.cprot[1] = datagram[9];
            }
    });
}

void FTPMassDown::getwaniport()
{
    //获取外网ip 写死了，没有实时获取
    QString sFl;
    QFile fL("/home/thtf/wan.txt");
    if(fL.open(QIODevice::ReadWrite|QIODevice::Text))
    {
        while (!fL.atEnd())
        {
            QByteArray line = fL.readAll();
            QString str(line);
            sFl = str;
        }
        fL.close();
    }
    QStringList sFll;
    sFll = sFl.split('\n');
    strwan.ip = sFll[0];
    strwan.port = sFll[1].toInt();
}

QString FTPMassDown::getlocalip()
{
    QString strIpAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    // 获取第一个本主机的IPv4地址
    int nListSize = ipAddressesList.size();
    for (int i = 0; i < nListSize; ++i)
    {
           if (ipAddressesList.at(i) != QHostAddress::LocalHost &&
               ipAddressesList.at(i).toIPv4Address()) {
               strIpAddress = ipAddressesList.at(i).toString();
               break;
           }
     }
     // 如果没有找到，则以本地IP地址为IP
     if (strIpAddress.isEmpty())
        strIpAddress = QHostAddress(QHostAddress::LocalHost).toString();
     return strIpAddress;
}

bool FTPMassDown::islanwan()
{
    if(1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

QString FTPMassDown::lscpu()
{
    //获取本机架构
    QProcess pro;
    pro.start("lscpu");
    pro.waitForFinished();
    QString lscpu = QString(pro.readAllStandardOutput().trimmed());
    QStringList cpu = lscpu.split(":");
    QString cpubuild;
    QString build;
    build.append(cpu[1]);
    for(int i=0;i<build.size();i++)
    {
        if(build[i]==" ")
        {
            continue;
        }
        else
        {
            if(build[i]=="\n")
            {
                break;
            }
            else
            {
                cpubuild.append(build[i]);
            }
        }
    }
    return cpubuild;
}

QString FTPMassDown::cpubuild()
{
    QString cpubuild;
    if(lscpu() == "x86_64")
    {
        cpubuild.append("amd64");
        cpubuild.append("i386");
        cpubuild.append("x86");
        return cpubuild;
    }
    else if(lscpu() == "aarch64")
    {
        cpubuild.append("arm64");
        cpubuild.append("aarch64");
        return cpubuild;
    }
    else if(lscpu() == "mips64el")
    {
        cpubuild.append("mips64el");
        return cpubuild;
    }
}

bool FTPMassDown::aptlist(QString filename,QString filever)
{
    QProcess pro;
    pro.start("apt list --installed");
    pro.waitForFinished();
    QString aptalreadyget = QString(pro.readAllStandardOutput().trimmed());
    QStringList aptalreadygetl = aptalreadyget.split("\n");
    for(int i = 0; i < aptalreadygetl.count(); i++)
    {
        if(aptalreadygetl[i].contains(filename)&&aptalreadygetl[i].contains(filever))
        {
            return false;
        }
        else//这个文件不存在,可以下载并安装
        {
            return true;
        }
    }
}

void FTPMassDown::aptget(QString filename)
{
    QStringList start;
    start<<"dpkg -i "<<filename;
    QProcess pro;
    pro.start("/usr/bin/dpkg",start);
    pro.waitForFinished();
}

