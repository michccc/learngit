#include "systeminf.h"
#include "ui_systeminf.h"
#include <QProcess>
#include <QDebug>
#include <QMessageBox>
#include <QScreen>
#include <QFile>
#include <QDir>
systeminf::systeminf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::systeminf)
{
    ui->setupUi(this);
    init();
}

systeminf::~systeminf()
{
    delete ui;
}
void systeminf::init()
{
//    ui->horizontalLayout_2->setMargin(0);
    QScreen *screen=QGuiApplication::primaryScreen ();
    QRect mm=screen->availableGeometry() ;
    int screen_width = mm.width();
    int screen_height = mm.height();

    QStringList slCPU = runShell("lscpu").trimmed().split('\n');
    QStringList slInf;
    for(int i = 0 ; i < slCPU.count() ; i++)
    {
        if(slCPU[i].contains("Core(s) per socket: ",Qt::CaseInsensitive))
        {
            slInf.clear();
            slInf = slCPU[i].split(':');
            if(slInf.count()>1)
                ui->labCORE->setText(slInf[1].trimmed());
        }
        if(slCPU[i].contains("Model name:",Qt::CaseInsensitive))
        {
            slInf.clear();
            slInf = slCPU[i].split(':');
            if(slInf.count()>1)
                ui->labCPU->setText(slInf[1].trimmed());
        }
    }

    ui->labSPEED->setText(runShell("cat /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_max_freq").left(4)+"MHz");
    if(ui->labSPEED->text().length()<5)
    {
        QString sCPU;
        QFile file("/home/cpuinf.txt");
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            while (!file.atEnd())
            {
                QByteArray line = file.readAll();
                QString str(line);
                sCPU = str;
            }
            file.close();
        }
        QStringList sl = sCPU.split('\n');
        if(sl.count()>1)
        {
            ui->labSPEED->setText(sl[0]+"MHz");
            ui->labCORE->setText(sl[1]);
        }

    }
    ui->labKER->setText(runShell("uname -r").trimmed());
    ui->labOS->setText(runShell("lsb_release -d").right(runShell("lsb_release -d").count()-12).trimmed());
    if(ui->labOS->text().contains("uos",Qt::CaseInsensitive))
    {
        QImage *imgOS = new QImage();
        imgOS->load(":/PCman_RES/UOS.png");
        ui->labOSLOGO->setPixmap(QPixmap::fromImage(*imgOS));

    }

    slInf.clear();
    slInf = runShell("lspci").trimmed().split('\n');
    for(int v = 0 ; v < slInf.count();v++)
    {
        if(slInf[v].contains("VGA compatible controller:",Qt::CaseInsensitive))
        {
            ui->labVGA->setText(slInf[v].right(slInf[v].length()-35).trimmed());
        }
    }

    QString sMEM = runShell("cat /proc/meminfo");
    QStringList listM = sMEM.split("\n");
    if(listM.count()>=1)
    {
        for (int imem = 0 ; imem < listM.count();imem++)
        {
            if(listM[imem].contains("MemTotal"))
            {
                QStringList listM1 = listM[imem].split(":");
                if(listM.count()>0)
                {
                    QStringList listM2 = listM1[1].split("k");
                    if(listM2.count()>0)
                        sMEM = listM2[0].trimmed();
                    else
                        sMEM = "unknown";
                }
            }
        }
    }


    QString sMEMType;
    QFile fM("/home/RAMinf.txt");
    if (fM.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!fM.atEnd())
        {
            QByteArray line = fM.readAll();
            QString str(line);
            sMEMType = str;
        }
        fM.close();
    }
    sMEMType.replace("Type:","类型 ");
    sMEMType.replace("Speed:","速率 ");
    ui->labMEM->setText("内存容量 "+QString::number(sMEM.toDouble()/1024/1024,'f',2)+"GB\n"+sMEMType);

    QString sHDD;
    QFile file("/home/diskinf.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            QByteArray line = file.readAll();
            QString str(line);
            sHDD = str;
        }
        file.close();
    }


    QStringList slHDD = sHDD.split("<==>\n");
//    if (slHDD.count()>1&&slHDD.count()<3)
//    {
//        QStringList sl0 = slHDD[0].split("\n");
//        if(sl0.count()>1)
//        {
//            ui->labHDD_2->hide();
//            ui->progresshdd0_2->hide();
//            ui->label_3->hide();
//            ui->labHDD->setText("硬盘型号 "+sl0[0]);
//            ui->progresshdd0->setValue(sl0[1].toDouble());
//            ui->label_2->setText(QString::number(sl0[2].toDouble()*(sl0[1].toDouble()/100)/1024/1024/1024,'f',2)+"GB已用"+"(共"+QString::number(sl0[2].toDouble()/1024/1024/1024,'f',2)+"GB)");
//        }
//    }

    if (slHDD.count()>1)
    {
        QStringList sl0 = slHDD[0].split("\n");
        QStringList sl1 = slHDD[1].split("\n");
        if(sl0.count()>1)
        {
            ui->labHDD_2->hide();
            ui->progresshdd0_2->hide();
            ui->label_3->hide();
            ui->labHDD->setText("硬盘型号 "+sl0[0]);
            ui->progresshdd0->setValue(sl0[1].toDouble());
            ui->label_2->setText(QString::number(sl0[2].toDouble()*(sl0[1].toDouble()/100)/1024/1024/1024,'f',2)+"GB已用"+"(共"+QString::number(sl0[2].toDouble()/1024/1024/1024,'f',2)+"GB)");
        }
        if(sl1.count()>1)
        {
            ui->labHDD_2->show();
            ui->progresshdd0_2->show();
            ui->label_3->show();
            ui->labHDD_2->setText("硬盘型号 "+sl1[0]);
            ui->progresshdd0_2->setValue(sl1[1].toDouble());
            ui->label_3->setText(QString::number(sl1[2].toDouble()*(sl1[1].toDouble()/100)/1024/1024/1024,'f',2)+"GB已用"+"(共"+QString::number(sl1[2].toDouble()/1024/1024/1024,'f',2)+"GB)");

        }
    }

    QString sUser = runShell("w");
    slInf.clear();
    slInf=sUser.split('\n');
    if(slInf.count()>2)
    {
        ui->labHost->setText(QDir::homePath().right(QDir::homePath().length()-6));
//        ui->labHost->setText("11111111111111111111111111111111111111111111111111111111111111111111111");
    }

}

QString systeminf::runShell(QString sCMD)
{

    QProcess process;
    process.start(sCMD);
    process.waitForFinished();
    QByteArray output = process.readAllStandardOutput();
    QString sOutput = output;
    return sOutput;
}
