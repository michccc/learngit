#include "help_about.h"
#include "ui_help_about.h"
#define VER "0.2.3"
#include <QFile>

help_about::help_about(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::help_about)
{
    ui->setupUi(this);
    strVer=VER;

    QFile fver("/usr/share/tfpcman/pcmanver.txt");
    if (fver.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!fver.atEnd())
        {
            QByteArray line = fver.readAll();
            QString str(line);
            strVer = str;
        }
        fver.close();
    }
    ui->label_4->setText(VER);

}

help_about::~help_about()
{
    delete ui;
}

void help_about::on_pushButton_clicked()
{
    this->close();
}
