#ifndef FLOATPAN_H
#define FLOATPAN_H

#include <QWidget>
#include <QIcon>
#include <QMouseEvent>
#include <QDebug>
#include <QtCharts>
#include <QPoint>
#include <QtGlobal>
#include <QPieSlice>
#include <QList>


namespace Ui {
class floatpan;
}

class floatpan : public QWidget
{
    Q_OBJECT

public:
    explicit floatpan(QWidget *parent = nullptr,QWidget *topWindow = nullptr);
    ~floatpan();
    void setCustomText(QString text);
    void mousePressEvent(QMouseEvent * event)override;
    void mouseMoveEvent(QMouseEvent * event)override;
    void mouseReleaseEvent(QMouseEvent * event)override;
    bool isPressedWindow;
    QPoint offset;
    QSplineSeries *flineNetup = new QSplineSeries();
    QSplineSeries *flineNetdown = new QSplineSeries();
    QChart *fchartNetup = new QChart();
    QChart *fchartNetdown = new QChart();
    bool fmove = true;
    void fslCPU(qreal icpu);
    void fslMEM(qreal imem0,qreal imem1);
    void floatup(QString up);
    void floatdown(QString down);
    void floatupunit(QString upunit);
    void floatdownunit(QString downunit);
    void floatlineup(qreal rxtx,qreal rdownR);
    void floatlinedown(qreal rxtx,qreal rdownR);


private:
    Ui::floatpan *ui;
protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private slots:
    void on_btnspeed_clicked();
};

#endif // FLOATPAN_H
