#ifndef SYSTEMINF_H
#define SYSTEMINF_H

#include <QWidget>

namespace Ui {
class systeminf;
}

class systeminf : public QWidget
{
    Q_OBJECT

public:
    explicit systeminf(QWidget *parent = nullptr);
    ~systeminf();
    void init();
    QString runShell(QString sCMD);
    QString sHDD; //HDD infmation
    QString sHDDUse;//HDD use
    QString sCPU; //cpu model
    QString sCORE;//cpu cores
    QString sSPEED;//cpu speed
    QString sOS;//OS name
    QString sKER; //kernel version
    QString sHOST;//this PC's HOSTname
    QString sMEM;//memory
    QStringList slVGA;//VGA card infmation

private:
    Ui::systeminf *ui;
};

#endif // SYSTEMINF_H
