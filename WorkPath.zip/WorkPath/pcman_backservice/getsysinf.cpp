#include "getsysinf.h"
#include <QProcess>
#include <QDebug>
#include <QFile>

GetSysInf::GetSysInf()
{

}
void GetSysInf::run()
{



    lDISKs.clear();
    lRAM.clear();
    lGRAPHICS.clear();
    QProcess pVRAM;
    QProcess pRAM;
    QProcess pDISKModel;
    slGetGRAPHICS <<"-c"<<"dmesg | grep 'VRAM RAM='";
    pVRAM.start("/bin/bash",slGetGRAPHICS);
    pVRAM.waitForFinished();
    QString sVRAM="";
    sVRAM = pVRAM.readAllStandardOutput();
    pVRAM.close();
    int iequ = -1;
    int im = -1;
    for(int i=0 ; i < sVRAM.count();i++ )
    {
        if(iequ==-1 && sVRAM[i] == '=')
        {
            iequ = i;
        }
        if(im == -1 && sVRAM[i] == ',')
        {
            im = i;
        }
    }
    if(iequ!=-1&&im!=-1)
    {
        sVRAM= sVRAM.mid(iequ+1,im-iequ-1);
        qDebug()<<sVRAM;
    }

    slGetGRAPHICS.clear();
    slGetGRAPHICS<<"-c"<<"lspci | grep VGA";


    slGetDISKs<<"-c"<<"fdisk -l | grep 'Disk /dev'";
    pDISKModel.start("/bin/bash",slGetDISKs);
    pDISKModel.waitForFinished();
    QStringList slDISKsize = QString(pDISKModel.readAllStandardOutput()).split('\n');
    for(int ild = 0 ; ild < slDISKsize.count()-1;ild++)
    {
        stDISK stD;
        QStringList slSizeB = slDISKsize[ild].split(',');
        if(slSizeB.count()>1&&(slDISKsize[ild].contains("ram",Qt::CaseInsensitive)==false))
        {
            QStringList slDev = slSizeB[0].split(":");
            if(slDev.count() > 1)
            {
                QString sDev = slDev[0].right(slDev[0].count()-4).trimmed();
                stD.sDev =sDev;
                qDebug()<<sDev;
            }

            QString sSize = slSizeB[1].left(slSizeB[1].count()-5).trimmed();
            stD.sSize = sSize;

            qDebug()<<sSize;
            lDISKs.append(stD);
        }

    }
    pDISKModel.close();

    slGetDISKs.clear();
    slGetDISKs<<"-c"<<"fdisk -l | grep 'Disk model'";
    pDISKModel.start("/bin/bash",slGetDISKs);
    pDISKModel.waitForFinished();
    QStringList slDISKModel = QString(pDISKModel.readAllStandardOutput()).split('\n');
    for(int ild = 0 ; ild < slDISKModel.count()-1;ild++)
    {
        stDISK stD;
        QStringList slModelB = slDISKModel[ild].split(':');
        if(slModelB.count()>1)
        {
            QString sModel = slModelB[1].trimmed();//.left(slModelB[1].count()-5);
            lDISKs[ild].sModel = sModel;
            qDebug()<<sModel;
        }
    }
    pDISKModel.close();

    for(int i = 0 ; i < lDISKs.count();i++)
    {
        slGetDISKs.clear();
        slGetDISKs<<"-c"<<"df -l | grep "+lDISKs[i].sDev;
        pDISKModel.start("/bin/bash",slGetDISKs);
        pDISKModel.waitForFinished();
        QStringList slDISKUsed = QString(pDISKModel.readAllStandardOutput()).split('\n');
        long int iused = 0;
        double iPa = 0.0;
        for(int n = 0 ;n < slDISKUsed.count()-1;n++)
        {
            QRegExp sep("\\s+");
            QStringList slUSED = slDISKUsed[n].split(sep);
            QString sUsed ;
            //            qDebug()<<slUSED;
            if(slUSED.count()>5)
            {
                sUsed = slUSED[slUSED.count()-4];
                //                qDebug()<<sUsed;
            }
            qDebug()<<slUSED;
            qDebug()<<iused<<" "<<sUsed.toLong()<<"sUsed\n";
            iused = sUsed.toLong()+iused;

        }

        qDebug()<<iused<<"used\n";
        double iu = iused/1;
        double it = (lDISKs[i].sSize.toLong())/1024;
        qDebug()<<lDISKs[i].sSize.toLong()/1024<<"tatol\n";
        iPa = (iu/it)*100;
        QString sPa = QString("%1").arg(iPa);
        qDebug()<<sPa;
        lDISKs[i].sPar = sPa;

        slGetDISKs.clear();
        QString sDevice = lDISKs[i].sDev.right(lDISKs[i].sDev.count()-4);
        slGetDISKs<<"-c"<<"cat /sys/block"+sDevice+"/removable ";
        pDISKModel.start("/bin/bash",slGetDISKs);
        pDISKModel.waitForFinished();
        sDevice = pDISKModel.readAllStandardOutput();
        int iremove = -1;
        iremove = sDevice.toInt();
        lDISKs[i].iRemove = iremove;
        lDISKs[i].sRemove = sDevice;
        qDebug()<<slGetDISKs<<iremove;
//        sleep(3);
    }
    pDISKModel.close();


    slGetRAM.clear();
    slGetRAM<<"-c"<<"dmidecode | grep MT/s";
    pRAM.start("/bin/bash",slGetRAM);
    pRAM.waitForFinished();
    QStringList slRAMSpeed = QString(pRAM.readAllStandardOutput()).split("\n");
    QString sRAMSpeed = slRAMSpeed[0].trimmed();

    slGetRAM.clear();
    slGetRAM<<"-c"<<"dmidecode | grep 'Type: DDR'";
    pRAM.start("/bin/bash",slGetRAM);
    pRAM.waitForFinished();
    QStringList slRAMType = QString(pRAM.readAllStandardOutput()).split("\n");
    QString sRAMType = slRAMType[0].trimmed();
    qDebug()<<sRAMSpeed<<sRAMType;

    QString sCpuf;
    QString sCpucore;
    slGetRAM.clear();
    slGetRAM<<"-c"<<"dmidecode | grep 'Max Speed'";
    pRAM.start("/bin/bash",slGetRAM);
    pRAM.waitForFinished();
    sCpuf = QString(pRAM.readAllStandardOutput()).trimmed().right(8).trimmed().left(4);

    slGetRAM.clear();
    slGetRAM<<"-c"<<"dmidecode | grep 'Core Count'";
    pRAM.start("/bin/bash",slGetRAM);
    pRAM.waitForFinished();
    sCpucore = QString(pRAM.readAllStandardOutput()).trimmed().right(1).trimmed();

    qDebug()<<sCpuf<<sCpucore;

    pRAM.close();


    qDebug()<<"Read ok";

    QFile fileCpu("/home/cpuinf.txt");
    fileCpu.open(QIODevice::WriteOnly);
    fileCpu.close();
    if(fileCpu.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&fileCpu);
        stream.seek(fileCpu.size());
        stream<<sCpuf;
        stream<<'\n';
        stream<<sCpucore;
        fileCpu.close();
    }
    qDebug()<<"Cpu ok";


    QFile file("/home/diskinf.txt");
    file.open(QIODevice::WriteOnly);
    file.close();
    if(file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&file);
        stream.seek(file.size());
        for(int i = 0 ; i < lDISKs.count();i++)
        {
            if(lDISKs[i].iRemove!=1)
            {
                stream<<lDISKs[i].sModel<<"\n";
                stream<<lDISKs[i].sPar<<"\n";
                stream<<lDISKs[i].sSize<<"\n";
            }
            stream<<"<==>"<<"\n";

        }

        file.close();
    }
    qDebug()<<"DISK ok";

    QFile RAMinffile("/home/RAMinf.txt");
    RAMinffile.open(QIODevice::WriteOnly);
    RAMinffile.close();
    if(RAMinffile.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&RAMinffile);
        stream.seek(RAMinffile.size());
        stream<<sRAMType<<"\n"<<sRAMSpeed;
        RAMinffile.close();
    }
    qDebug()<<"RAM ok";


    QFile VRAMinffile("/home/VRAMinf.txt");
    VRAMinffile.open(QIODevice::WriteOnly);
    VRAMinffile.close();
    if(VRAMinffile.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&VRAMinffile);
        stream.seek(VRAMinffile.size());
        stream<<sVRAM<<"\n";
        VRAMinffile.close();
    }

    QRegExp sep("\\s+");
    QProcess pUser;
    pUser.start("w");
    pUser.waitForFinished();
    QString sgUser = QString(pUser.readAllStandardOutput().trimmed()).split('\n')[2].split(sep)[0].trimmed();
    QFile wf("/home/w.txt");
    wf.open(QIODevice::WriteOnly);
    wf.close();
    if(wf.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&wf);
        stream.seek(wf.size());
        stream<<sgUser;
        wf.close();
    }

    qDebug()<<"quit";
    this->quit();
}
