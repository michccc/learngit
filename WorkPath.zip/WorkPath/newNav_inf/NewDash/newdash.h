#ifndef NEWDASH_H
#define NEWDASH_H

#include <QWidget>
#include <QtCharts>
#include <QPieSlice>
#include "speedyball.h"


namespace Ui {
class NewDash;
}

class NewDash : public QWidget
{
    Q_OBJECT

public:
    explicit NewDash(QWidget *parent = nullptr);
    ~NewDash();
    void init();
    void updateData(qreal iMEM0, qreal iMEM1, qreal iCPU0, qreal iCPU1, int idown, int iup);

    QCategoryAxis *axisDown;
    QCategoryAxis *axisUp;
    QString defaultNetworkInterface;
    QString rxPath;
    QString txPath;

    QString rxTotal;
    QString txTotal;

    QString rxSec;
    QString txSec;

    qreal rxMax;
    qreal txMax;

    QStringList slCPUcmd;//get cpu infmation
    QStringList slMEMcmd;//get memory infmation
    QStringList slNETcmd;//get network infmation

    QPieSeries *serise = new QPieSeries();
    QPieSlice *slice0 = new QPieSlice();
    QPieSlice *slice1 = new QPieSlice();
    QChart *chart = new QChart();

    QPieSeries *seriseMEM = new QPieSeries();
    QPieSlice *sliceMEM0 = new QPieSlice();
    QPieSlice *sliceMEM1 = new QPieSlice();
    QChart *chartMEM = new QChart();

    QPieSeries *seriseDISK = new QPieSeries();
    QPieSlice *sliceDISK0 = new QPieSlice();
    QPieSlice *sliceDISK1 = new QPieSlice();
    QChart *chartDISK = new QChart();

    QLineSeries *seriseNetup = new QLineSeries();
    QLineSeries *seriseNetdown = new QLineSeries();
    QSplineSeries *lineNetup = new QSplineSeries();
    QSplineSeries *lineNetdown = new QSplineSeries();
    QChart *chartNetup = new QChart();
    QChart *chartNetdown = new QChart();
    speedyball *s;
protected:
    void timerEvent(QTimerEvent *event);
private:
    Ui::NewDash *ui;
};

#endif // NEWDASH_H
