#ifndef SOFTMAN_H
#define SOFTMAN_H

#include <QWidget>

namespace Ui {
class softMan;
}

class softMan : public QWidget
{
    Q_OBJECT

public:
    explicit softMan(QWidget *parent = nullptr);
    ~softMan();

    bool bRebtn;
    QString sFilter;
    struct sturepo
    {
        QString sAddress;
        QString sPATH;
        int     iLien;
        QString sComment;
        void clear()
        {
            sAddress="";
            sPATH="";
            iLien=0;
            sComment="";
        }
    };
    QList <sturepo> lRepo;
    int gC = -1;
    int getRepo();
    void reconRepo(QString sNewAddr, int index);


    int getPack();

    void setTab(int index);

protected:
    void timerEvent(QTimerEvent *event);

public slots:
//
//    void settingTableChanged(int row, int col);

private slots:
    void on_tableRepo_cellClicked(int row, int column);
    void OnBtnClicked();

    void on_pushEdit_clicked();

    void on_pushAdd_clicked();

    void on_pushDel_clicked();

    void on_pushDel_2_clicked();

    void on_pushButton_clicked();

    void on_pushSearch_clicked();

    void on_lineEdit_returnPressed();

private:
    Ui::softMan *ui;
};

#endif // SOFTMAN_H
