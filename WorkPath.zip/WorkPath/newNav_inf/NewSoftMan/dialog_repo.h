#ifndef DIALOG_REPO_H
#define DIALOG_REPO_H

#include <QDialog>
#include "softman.h"

namespace Ui {
class Dialog_repo;
}

class Dialog_repo : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_repo(QString aAddress,int index,QWidget *parent = nullptr);
    ~Dialog_repo();
    int parIndex = -1;
    QString parStr;
    softMan* softW;

private slots:
    void on_pushreboCan_clicked();

    void on_pushrepook_clicked();

private:
    Ui::Dialog_repo *ui;
};

#endif // DIALOG_REPO_H
